#include "image_properties.h"
//ros libraries
#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "nav_msgs/OccupancyGrid.h"
//c++ libraries
#include <iostream>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <string>
#include <fstream>

using namespace cv;
using namespace std;

namespace enc = sensor_msgs::image_encodings;

ros::Subscriber sub_Lanedata_left;
//Use method of ImageTransport to create image publisher
image_transport::Publisher pub_left;

Rect* RightROI;
Rect* LeftROI;
Point p_left,p_right;


Mat src,temp1,temp2,temp3,temp4,blank,dst,blue,map1_left,map2_left,map1_right,map2_right,src_right,gray1,gray2,diff;
vector<Mat> BGR;
Mat kernel_dilate;


void leftimage(const sensor_msgs::ImageConstPtr& original_image)
{
	cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(original_image, enc::BGR8);
	}
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("videofeed::igvc_IPM.cpp::cv_bridge exception: %s", e.what());
        return;
    }

    src = cv_ptr->image;
    //remap(src, temp3, map1_left, map2_left, CV_INTER_LINEAR);
    temp3=src;
    cvtColor(temp3,temp3,CV_BGR2GRAY);
    Mat dst=Mat::zeros(Size(temp3.rows, temp3.cols), CV_8U);
    // dst= Mat.zeros(temp3.rows(), temp3.cols(), CV_8U);
    int aux=0,tau=1;
    namedWindow("test_roi",CV_WINDOW_AUTOSIZE);
    createTrackbar("tau","test_roi", &tau, 100);
    tau = getTrackbarPos("tau","test_roi");
    for(int j=0;j<src.rows;j++){
        unsigned char* ptRowSrc = src.ptr<uchar>(j);
        unsigned char* ptRowDst = dst.ptr<uchar>(j);

        for(int i =tau; i<src.cols-tau; i++){
            if(ptRowSrc[i]!=0){
                aux=2*ptRowSrc[i];
                aux+= -ptRowSrc[i-tau];
                aux+= -ptRowSrc[i+tau];
                aux+=-abs((int)(ptRowSrc[i-tau]-ptRowSrc[i+tau]));

                aux = (aux<0)?(0):(aux);
                aux = (aux>255)?(255):(aux);

                ptRowDst[i] = (unsigned char)aux;
            }
        }

    }
    imshow("temp3",temp3);
    imshow("dst",dst);
	cv_ptr->image = dst;
    pub_left.publish(cv_ptr->toImageMsg());
    waitKey(1);
}


int main(int argc, char **argv)
{	
    ros::init(argc, argv, "Lane_D");
    ros::NodeHandle nh1;

	image_transport::ImageTransport it1(nh1);
	image_transport::Subscriber sub_left = it1.subscribe("/camera/image_raw", 1, leftimage);


	ros::Rate loop_rate(20);

	  std::ifstream matleft("/home/anish/catkin_ws/src/vatsal/src/NL_intrinsic_matrix_left.txt",std::ios::in);
	  std::ifstream distleft("/home/anish/catkin_ws/src/vatsal/src/NL_distCoeff_left.txt",std::ios::in);


	std::vector<double> a;
	std::vector<double> distCoeff_left;
	 double num1 = 0.0;
	while (matleft >> num1) {
        a.push_back(num1);
    }
    double num2 = 0.0;
    while (distleft >> num2) {
        distCoeff_left.push_back(num2);
    }
    matleft.close();
    distleft.close();
    Mat intrinsic_matrix_left = (Mat_<double>(3,3) << a[0], a[1], a[2], a[3],a[4], a[5], a[6], a[7], a[8]);
    //Mat newmat_left = getOptimalNewCameraMatrix(intrinsic_matrix_left, distCoeff_left,Size (1280,720), 5.5,Size (1280,720), LeftROI, true);
    initUndistortRectifyMap(intrinsic_matrix_left, distCoeff_left, Mat::eye(3, 3, CV_16S), intrinsic_matrix_left, Size (1280,720), CV_32FC1, map1_left, map2_left);
    a.clear();
    distCoeff_left.clear();
    //newmat_left.release();
    intrinsic_matrix_left.release();

	while(ros::ok())
	{	
		ros::spinOnce();
		loop_rate.sleep();
		
	}

	ROS_INFO("videofeed::occupancygrid.cpp::No error.");

}