#include "image_properties.h"
#include "opencv2/core.hpp"
#include "opencv2/features2d.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/xfeatures2d.hpp"
//ros libraries
#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "nav_msgs/OccupancyGrid.h"
//c++ libraries
#include <iostream>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <string>
#include <fstream>

using namespace std;
using namespace cv;
using namespace cv::xfeatures2d;

namespace enc = sensor_msgs::image_encodings;

/*
 * @function readme
 */
ros::Subscriber sub_Lanedata_left;
ros::Subscriber sub_Lanedata_right;
//Use method of ImageTransport to create image publisher
image_transport::Publisher pub_left;
image_transport::Publisher pub_right;

void rightimage(const sensor_msgs::ImageConstPtr& original_image)
{
cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(original_image, enc::BGR8);
	}
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("videofeed::igvc_IPM.cpp::cv_bridge exception: %s", e.what());
        return;
    }
    src_right = cv_ptr->image;

    pub_right.publish(cv_ptr->toImageMsg());
    waitKey(1);
}

void leftimage(const sensor_msgs::ImageConstPtr& original_image)
{
	cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(original_image, enc::BGR8);
	}
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("videofeed::igvc_IPM.cpp::cv_bridge exception: %s", e.what());
        return;
    }

    src = cv_ptr->image;

    pub_left.publish(cv_ptr->toImageMsg());
    waitKey(1);
}


int main(int argc, char **argv)
{	
    ros::init(argc, argv, "Lane_D");
    ros::NodeHandle nh1;
    ros::NodeHandle nh2;

	image_transport::ImageTransport it1(nh1);
	image_transport::ImageTransport it2(nh2);
	image_transport::Subscriber sub_left = it1.subscribe("/camera1/image_raw", 1, rightimage);
	image_transport::Subscriber sub_right = it2.subscribe("/camera3/image_raw", 1, leftimage);


	ros::Rate loop_rate(2);
	while(ros::ok())
	{	
		ros::spinOnce();
		// distance();
		loop_rate.sleep();	
	}
	ROS_INFO("videofeed::occupancygrid.cpp::No error.");
}