#include "image_properties.h"
#include "opencv2/core.hpp"
#include "opencv2/features2d.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/xfeatures2d.hpp"
//ros libraries
#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "nav_msgs/OccupancyGrid.h"
//c++ libraries
#include <iostream>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <string>
#include <fstream>


using namespace std;
using namespace cv;
using namespace cv::xfeatures2d;

namespace enc = sensor_msgs::image_encodings;

  // int minHessian = 400;
  // Ptr<SURF> detector = SURF::create();
  // detector->setHessianThreshold(minHessian);
std::vector<KeyPoint> keypoints_1, keypoints_2;
Mat descriptors_1, descriptors_2;



/*
 * @function readme
 */
ros::Subscriber sub_Lanedata_left;
ros::Subscriber sub_Lanedata_right;
//Use method of ImageTransport to create image publisher
image_transport::Publisher pub_left;
image_transport::Publisher pub_right;

const double TOTAL_WIDTH=1280.0, TOTAL_HEIGHT=720.0;

int hue_low = 200;
int hue_high = 255;
int sat_low = 170;
int sat_high =255;
int val_low = 130;
int val_high =255;
int circle_sensitivity=10;
int found=0;
int center_1,center_2;

int roi_hue_low = 240;
int roi_hue_high = 255;
int roi_sat_low = 170;
int roi_sat_high =255;
int roi_val_low = 0;
int roi_val_high =255;

double x1,x2;
Rect* RightROI;
Rect* LeftROI;
Point p_left,p_right;

double A=0.28,B=608,C=11,dist;

Mat src,temp1,temp2,temp3,temp4,blank,dst,blue,map1_left,map2_left,map1_right,map2_right,src_right,gray1,gray2,diff;
vector<Mat> BGR;
Mat kernel_dilate;
int thresh = 100;
int max_thresh = 255;
RNG rng(12345);
  // int minHessian = 400;
   Ptr<SURF> detector = SURF::create();
   Mat img_matches,cropped1,cropped2,roi1,roi2;
   double mean_dist,disp,c_1,c_2;



Mat equalizeIntensity(const Mat& inputImage)
{
    if(inputImage.channels() >= 3)
    {
        Mat ycrcb;

        // cvtColor(inputImage,ycrcb,CV_BGR2YCrCb);

        vector<Mat> channels;
        split(inputImage,channels);

        equalizeHist(channels[0], channels[0]);
        equalizeHist(channels[1], channels[1]);
        equalizeHist(channels[2], channels[2]);
        //Mat result;
        merge(channels,ycrcb);

        // cvtColor(ycrcb,result,CV_YCrCb2BGR);

        return ycrcb;
    }
    return Mat();
}

double distance(double disparity){
  return A-B/(disparity+C);
}
void display_distance(){

		std::ostringstream strs1,strs2,strs3,strs4,strs5;
    disp=c_1-c_2;
		strs1 << abs(disp);
		std::string str1 = strs1.str();

    mean_dist=x1-x2;
		strs2 << abs(mean_dist);
		std::string str2 = strs2.str();

		disp+=mean_dist;
		strs3 << abs(disp);
		std::string str3 = strs3.str();
    //int diff=center_1-center_2;
    

    dist=distance(disp);
    strs5 << dist;
    std::string str5 = strs5.str();
		cv::Mat pic = cv::Mat::zeros(250,250,CV_8UC3);

		// cv::putText(pic, "Disp:"+str1,cv::Point(50,50), CV_FONT_HERSHEY_SIMPLEX, 0.5,cv::Scalar(255),1,8,false);
		// cv::putText(pic, "Mean_dist:"+str2,cv::Point(50,100), CV_FONT_HERSHEY_SIMPLEX, 0.5,cv::Scalar(255),1,8,false);
		cv::putText(pic, "Disparity:"+str3,cv::Point(50,50), CV_FONT_HERSHEY_SIMPLEX, 0.5,cv::Scalar(255),1,8,false);
    cv::putText(pic, "Distance:"+str5,cv::Point(50,100), CV_FONT_HERSHEY_SIMPLEX, 0.5,cv::Scalar(255),1,8,false);

		imshow("Distance",pic);
		// gray_diff();
	}
//  return abs(b*f/((x1-x2)));


Mat give_roi(Mat bluebarrel,string cam)
{	
	Mat bw,initial,cropped=Mat::zeros(cvSize(100, 100), CV_8UC3),bhsw;
	cvtColor(bluebarrel,bhsw, CV_RGB2HSV);
  bhsw=equalizeIntensity( bhsw );
  //return bhsw;
	namedWindow("test_main"+cam,CV_WINDOW_AUTOSIZE);
	createTrackbar("hue_low","test_main"+cam, &hue_low, 255);
	createTrackbar("hue_high","test_main"+cam, &hue_high,255);
	createTrackbar("sat_low","test_main"+cam, &sat_low,255);
	createTrackbar("sat_high","test_main"+cam, &sat_high, 255);
	createTrackbar("val_low","test_main"+cam, &val_low, 255);
	createTrackbar("val_high","test_main"+cam, &val_high, 255);
	createTrackbar("circle_sensitivity","test_main"+cam, &circle_sensitivity, 100);
  //createTrackbar("hessian_threshold","test_main"+cam, &minHessian, 1000);
	hue_low = getTrackbarPos("hue_low","test_main"+cam);
	hue_high = getTrackbarPos("hue_high","test_main"+cam);
	sat_low = getTrackbarPos("sat_low","test_main"+cam);
	sat_high = getTrackbarPos("sat_high","test_main"+cam);
	val_low = getTrackbarPos("val_low","test_main"+cam);
	val_high = getTrackbarPos("val_high","test_main"+cam);
  //minHessian = getTrackbarPos("hessian_threshold","test_main"+cam);
	inRange(bhsw,Scalar(hue_low,sat_low,val_low),Scalar(hue_high,sat_high,val_high),bw);//detects red
	//erode(bw, bw, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)) );

	GaussianBlur( bw, bw, Size(9, 9), 0,0);
	imshow("test_main"+cam,bw);
  	vector<Vec3f> circles;
  	HoughCircles( bw, circles, CV_HOUGH_GRADIENT, 1, bw.rows/8, 100,getTrackbarPos("circle_sensitivity","test_main"+cam), 5, 0 );
  	//cout<<circles.size();
  	  waitKey(1);
  	for( int i = 0; i < circles.size(); i++ )
  	{
      Point center(cvRound(circles[i][0]), cvRound(circles[i][1]));
      double radius = cvRound(circles[i][2]);
          //	 Mat cropped(bluebarrel,Rect(max(circles[i][0]-2*radius,0),max(circles[i][1]-2*radius,0),min(4*radius,TOTAL_WIDTH-(circles[i][0]+2*radius)),min(4*radius,TOTAL_WIDTH-(circles[i][0]+2*radius))));
      double margin=3;
      double x1=circles[i][0],y1=circles[i][1];
      double xc=max(x1-margin*radius,0.0);
      double yc=max(y1-margin*radius,0.0);
      double w=min(2*margin*radius,TOTAL_WIDTH-xc);
      double h=min(2*margin*radius,TOTAL_HEIGHT-yc);
      printf("Dimensions %f %f %f %f\n",xc,yc,w,h);
      if(cam=="R"){
      c_1=xc;
      center_1=x1;
    }
  	else{
  		c_2=xc;
      center_2=x1;
    }
      Mat cropped(bluebarrel,Rect(xc,yc,w,h));
      	found++;
        // cropped=equalizeIntensity( cropped );

   	    //cvtColor(cropped,cropped, cv::COLOR_BGR2GRAY);
        //equalizeHist(cropped,cropped);
      return cropped;
   }
   return bluebarrel;
}

void ellipsefit(Mat roi,string cam){

  Mat initial,bhsw,src_gray;
  cvtColor(roi,bhsw, CV_RGB2HSV);
  bhsw=equalizeIntensity( bhsw );
  //return bhsw;
  namedWindow("test_roi"+cam,CV_WINDOW_AUTOSIZE);
  createTrackbar("roi_hue_low","test_roi"+cam, &roi_hue_low, 255);
  createTrackbar("roi_hue_high","test_roi"+cam, &roi_hue_high,255);
  createTrackbar("roi_sat_low","test_roi"+cam, &roi_sat_low,255);
  createTrackbar("roi_sat_high","test_roi"+cam, &roi_sat_high, 255);
  createTrackbar("roi_val_low","test_roi"+cam, &roi_val_low, 255);
  createTrackbar("roi_val_high","test_roi"+cam, &roi_val_high, 255);
  // createTrackbar("circle_sensitivity","test_roi"+cam, &circle_sensitivity, 100);
  //createTrackbar("hessian_threshold","test_roi"+cam, &minHessian, 1000);
  hue_low = getTrackbarPos("roi_hue_low","test_roi"+cam);
  hue_high = getTrackbarPos("roi_hue_high","test_roi"+cam);
  sat_low = getTrackbarPos("roi_sat_low","test_roi"+cam);
  sat_high = getTrackbarPos("roi_sat_high","test_roi"+cam);
  val_low = getTrackbarPos("roi_val_low","test_roi"+cam);
  val_high = getTrackbarPos("roi_val_high","test_roi"+cam);
  //minHessian = getTrackbarPos("hessian_threshold","test_main"+cam);
  inRange(bhsw,Scalar(roi_hue_low,roi_sat_low,roi_val_low),Scalar(roi_hue_high,roi_sat_high,roi_val_high),src_gray);//detects red
  GaussianBlur( src_gray,src_gray, Size(3,3), 0,0);
  imshow("test_roi"+cam,src_gray);
  Mat threshold_output;
  vector<vector<Point> > contours;
  vector<Vec4i> hierarchy;

  /// Detect edges using Threshold
  threshold( src_gray, threshold_output, thresh, 255, THRESH_BINARY );
  /// Find contours
  findContours( threshold_output, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0) );

  /// Find the rotated rectangles and ellipses for each contour
  vector<RotatedRect> minRect( contours.size() );
  vector<RotatedRect> minEllipse( contours.size() );
  double max_size=5;
  int max_pos=-1;
  for( int i = 0; i < contours.size(); i++ )
     { minRect[i] = minAreaRect( Mat(contours[i]) );
       if( contours[i].size() >= max_size ){
          max_size=contours[i].size();
          max_pos=i;
       }
     }


  /// Draw contours + rotated rects + ellipses
  Mat drawing = Mat::zeros( threshold_output.size(), CV_8UC3 );
       if(max_pos>-1){
        minEllipse[max_pos] = fitEllipse( Mat(contours[max_pos]) );
       Scalar color = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
       // contour
       drawContours( drawing, contours, max_pos, color, 1, 8, vector<Vec4i>(), 0, Point() );
       // ellipse
       ellipse( drawing, minEllipse[max_pos], color, 2, 8 );
       // rotated rectangle
       Point2f rect_points[4]; minRect[max_pos].points( rect_points );
       for( int j = 0; j < 4; j++ )
          line( drawing, rect_points[j], rect_points[(j+1)%4], color, 1, 8 );
      Point2f ellipse_center=minEllipse[max_pos].center;
      if(cam=="R"){
      x1=ellipse_center.x;
      }
      else{
        x2=ellipse_center.x;
      }
    
}

  /// Show in a window
  namedWindow( "Contours"+cam, CV_WINDOW_AUTOSIZE );
  imshow( "Contours"+cam, drawing );
  waitKey(1);

}
void rightimage(const sensor_msgs::ImageConstPtr& original_image)
{
cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(original_image, enc::BGR8);
	}
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("videofeed::igvc_IPM.cpp::cv_bridge exception: %s", e.what());
        return;
    }
    src_right = cv_ptr->image;
    imshow("origR",src_right);
    temp1=src_right.clone();
    remap(src_right, temp1, map1_right, map2_right, CV_INTER_LINEAR,BORDER_CONSTANT);
     found=0;
     //temp1=equalizeIntensity( temp1 );
     cropped1=give_roi(temp1,"R");
     cropped1.copyTo(roi1);
     imshow("ROI_R",roi1);
    if(found==1)
      ellipsefit(roi1,"R");
    //detector->detectAndCompute( roi1, Mat(), keypoints_1, descriptors_1 );
     imshow("sampleR",temp1);

 //    cv_ptr->image = temp1;
    // pub_right.publish(cv_ptr->toImageMsg());
    waitKey(1);
}

void leftimage(const sensor_msgs::ImageConstPtr& original_image)
{
	cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(original_image, enc::BGR8);
	}
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("videofeed::igvc_IPM.cpp::cv_bridge exception: %s", e.what());
        return;
    }

    src = cv_ptr->image;
    imshow("origL",src);
     temp3=src.clone();
    remap(src, temp3, map1_left, map2_left, CV_INTER_LINEAR,BORDER_CONSTANT);
    //temp3=equalizeIntensity( temp3 );
    cropped2=give_roi(temp3,"L");
      cropped2.copyTo(roi2);
     

     if(found==2){
      ellipsefit(roi2,"L");
      //detector->detectAndCompute( roi2, Mat(), keypoints_2, descriptors_2 );
		 //sift();
		 display_distance();
	}
    imshow("ROI_L",roi2);
    imshow("sampleL",temp3);
    printf("%d \n",found);
	cv_ptr->image = temp3;
    pub_left.publish(cv_ptr->toImageMsg());
    waitKey(1);
}


int main(int argc, char **argv)
{	
    ros::init(argc, argv, "Lane_D");
    ros::NodeHandle nh1;
    ros::NodeHandle nh2;

	image_transport::ImageTransport it1(nh1);
	image_transport::ImageTransport it2(nh2);
	image_transport::Subscriber sub_right = it1.subscribe("/camera1/image_raw", 1, rightimage);
	image_transport::Subscriber sub_left = it2.subscribe("/camera3/image_raw", 1, leftimage);
  ros::Rate loop_rate(20);

  std::ifstream matleft("/home/anish/catkin_ws/src/vatsal/src/intrinsic_matrix_left (copy).txt",std::ios::in);
  std::ifstream distleft("/home/anish/catkin_ws/src/vatsal/src/distCoeff_left (copy).txt",std::ios::in);
  std::ifstream matright("/home/anish/catkin_ws/src/vatsal/src/intrinsic_matrix_right (copy).txt",std::ios::in);
  std::ifstream distright("/home/anish/catkin_ws/src/vatsal/src/distCoeff_right (copy).txt",std::ios::in);

  // std::ifstream matleft("/home/anish/catkin_ws/src/vatsal/src/intrinsic_matrix_left.txt",std::ios::in);
  // std::ifstream distleft("/home/anish/catkin_ws/src/vatsal/src/distCoeff_left.txt",std::ios::in);
  // std::ifstream matright("/home/anish/catkin_ws/src/vatsal/src/intrinsic_matrix_right.txt",std::ios::in);
  // std::ifstream distright("/home/anish/catkin_ws/src/vatsal/src/distCoeff_right.txt",std::ios::in);

  // std::ifstream matleft("/home/anish/catkin_ws/src/vatsal/src/NL_intrinsic_matrix_left.txt",std::ios::in);
  // std::ifstream distleft("/home/anish/catkin_ws/src/vatsal/src/NL_distCoeff_left.txt",std::ios::in);
  // std::ifstream matright("/home/anish/catkin_ws/src/vatsal/src/NR_intrinsic_matrix_right.txt",std::ios::in);
  // std::ifstream distright("/home/anish/catkin_ws/src/vatsal/src/NR_distCoeff_right.txt",std::ios::in);

  std::vector<double> a,b;
  std::vector<double> distCoeff_left;
   double num1 = 0.0;
  while (matleft >> num1) {
        a.push_back(num1);
    }
    double num2 = 0.0;
    while (distleft >> num2) {
        distCoeff_left.push_back(num2);
    }
    matleft.close();
    distleft.close();
    Mat intrinsic_matrix_left = (Mat_<double>(3,3) << a[0], a[1], a[2], a[3],a[4], a[5], a[6], a[7], a[8]);
    //Mat newmat_left = getOptimalNewCameraMatrix(intrinsic_matrix_left, distCoeff_left,Size (TOTAL_WIDTH,TOTAL_HEIGHT), 5.5,Size (TOTAL_WIDTH,TOTAL_HEIGHT), LeftROI, true);
    //Mat newmat_left = getOptimalNewCameraMatrix(intrinsic_matrix_left, distCoeff_left,Size (TOTAL_WIDTH,TOTAL_HEIGHT),0,Size (TOTAL_WIDTH,TOTAL_HEIGHT), LeftROI,true);
    // cout<<newmat_left<<endl;
    Mat R=Mat::eye(3, 3, CV_8U);
    //cout<<map2_left.row(0)<<endl;
    initUndistortRectifyMap(intrinsic_matrix_left, distCoeff_left, R,intrinsic_matrix_left, Size (TOTAL_WIDTH,TOTAL_HEIGHT), CV_32FC1, map1_left, map2_left);
    cout<<R;
    cout<<map2_left.row(0)<<endl;
    cout<<intrinsic_matrix_left;
    a.clear();
    distCoeff_left.clear();
    //newmat_left.release();
    intrinsic_matrix_left.release();

  std::vector<double> distCoeff_right;
  num1 = 0.0;
  while (matright >> num1) {
         b.push_back(num1);
         cout<<num1<<endl;
     }
     num2 = 0.0;
     while (distright >> num2) {
         distCoeff_right.push_back(num2);
         cout<<num2<<endl;
     }
     matright.close();
     distright.close();

      Mat intrinsic_matrix_right = (Mat_<double>(3,3) << b[0], b[1], b[2], b[3],b[4], b[5], b[6], b[7], b[8]);
  //    //Mat newmat_right = getOptimalNewCameraMatrix(intrinsic_matrix_right, distCoeff_right,Size (TOTAL_WIDTH,TOTAL_HEIGHT), 5.8,Size (TOTAL_WIDTH,TOTAL_HEIGHT), RightROI, true);
  //    //Mat newmat_right = getOptimalNewCameraMatrix(intrinsic_matrix_right, distCoeff_right,Size (TOTAL_WIDTH,TOTAL_HEIGHT),0,Size (TOTAL_WIDTH,TOTAL_HEIGHT), RightROI, true);

      initUndistortRectifyMap(intrinsic_matrix_right, distCoeff_right, R,intrinsic_matrix_right, Size (TOTAL_WIDTH,TOTAL_HEIGHT),CV_32FC1, map1_right, map2_right);
     b.clear();
     distCoeff_right.clear();
     //newmat_right.release();
     intrinsic_matrix_right.release();


	while(ros::ok())
	{	
		ros::spinOnce();
		// distance();
		loop_rate.sleep();	
	}
	ROS_INFO("videofeed::occupancygrid.cpp::No error.");
}