#include "image_properties.h"
//ros libraries
#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "nav_msgs/OccupancyGrid.h"
//c++ libraries
#include <iostream>
#include <vector>
#include <math.h>
#include <string>
#include <fstream>


using namespace cv;
using namespace std;

namespace enc = sensor_msgs::image_encodings;

ros::Subscriber sub_Lanedata_left;
// ros::Subscriber sub_Lanedata_right;
//Use method of ImageTransport to create image publisher
image_transport::Publisher pub_left;

Rect* LeftROI; 
int bv = 9;
int c = 100;
int ksize = 1;
int area = 25;
int hue_low = 20;
int hue_high = 60;
int sat_low = 20;
int sat_high = 60;
int val_low = 72;
int val_high = 120;
float scale=1;
float dpi=72;

float cam_dist=0.19;
float f=0.00414;

double num3 = 0.0;
double num4 = 0.0;

std::vector<std::vector<Point> > contours;
std::vector<Vec4i> hierarchy;
std::vector<std::vector<Point> > contours_blue;
std::vector<Vec4i> hierarchy_blue;



  std::vector<double> a;
  std::vector<double> distCoeff_right;

Mat src1,src2,temp1,temp2,temp3,temp4,blank,dst,blue,map1_left,map2_left;
vector<Mat> BGR;
Point p1,p2;

void distance(){
//  if(p_left.x>=0&&p_right.x>=0)
  // if(p1.x>=0&&p2.x>=0&&abs(p1.y-p2.y)<100)
    if(p1.x>=0&&p2.x>=0)
//  return abs(b*f/((p_left.x-p_right.x)*0.0254*0.0254/72.0));
    cout<<abs(cam_dist*f/((p1.x-p2.x)*0.0254*0.0254/dpi))<<endl;
//  return abs(b*f/((x1-x2)));
}

Point removeblue(Mat bluebarrel,string cam)
{	
	Mat bw,initial;
	
	namedWindow("test_left"+cam,CV_WINDOW_AUTOSIZE);
	createTrackbar("hue_low","test_left"+cam, &hue_low, 255);
	createTrackbar("hue_high","test_left"+cam, &hue_high, 255);
	createTrackbar("sat_low","test_left"+cam, &sat_low, 255);
	createTrackbar("sat_high","test_left"+cam, &sat_high, 255);
	createTrackbar("val_low","test_left"+cam, &val_low, 255);
	createTrackbar("val_high","test_left"+cam, &val_high, 255);
	hue_low = getTrackbarPos("hue_low","test_left"+cam);
	hue_high = getTrackbarPos("hue_high","test_left"+cam);
	sat_low = getTrackbarPos("sat_low","test_left"+cam);
	sat_high = getTrackbarPos("sat_high","test_left"+cam);
	val_low = getTrackbarPos("val_low","test_left"+cam);
	val_high = getTrackbarPos("val_high","test_left"+cam);
	inRange(bluebarrel,Scalar(hue_low,sat_low,val_low),Scalar(hue_high,sat_high,val_high),bw);//detects blue
	
	// findContours( bw, contours_blue, hierarchy_blue, CV_RETR_TREE, CV_CHAIN_APPROX_NONE);
	GaussianBlur( bw, bw, Size(9, 9), 0,0);
	imshow("test_left"+cam,bw);
  	vector<Vec3f> circles;
  	HoughCircles( bw, circles, CV_HOUGH_GRADIENT, 1, bw.rows/8, 100, 40, 0, 0 );
  	// cout<<circles.size()<<" Cam"<<cam<<" ";
  	// Draw the circles detected
  	for( int i = 0; i < circles.size(); i++ )
  	{
      Point center(cvRound(circles[i][0]), cvRound(circles[i][1]));
      int radius = cvRound(circles[i][2]);
   	  // if(radius<100) continue;
      // circle center
      circle( bluebarrel, center, 3, Scalar(0,255,0), -1, 8, 0 );
      // circle outline
      circle( bluebarrel, center, radius, Scalar(0,0,255), 3, 8, 0 );
      imshow("Detected red circles on the input image"+cam, bluebarrel);

      return center;
      // waitKey(1);
   }
   Point p_null(-1,-1);
   return p_null;
}

void leftimage(const sensor_msgs::ImageConstPtr& original_image)
{
  // std::ifstream matleft("/home/anish/catkin_ws/src/vatsal/src/intrinsic_matrix_left.txt",std::ios::in);
  // std::ifstream distleft("/home/anish/catkin_ws/src/vatsal/src/distCoeff_left.txt",std::ios::in);

  // num3 = 0.0;

  // while (matleft >> num3) {
  //       b.push_back(num3);
  //   }
 	// num4 = 0.0;
  //   while (distleft >> num4) {
  //       distCoeff_left.push_back(num4);
  //   }
  //       matleft.close();

  //   distleft.close();
  //   Mat intrinsic_matrix_left = (Mat_<double>(3,3) << b[0], b[1], b[2], b[3],b[4], b[5], b[6], b[7], b[8]);
  //   Mat newmat_left = getOptimalNewCameraMatrix(intrinsic_matrix_left, distCoeff_left,Size (1280,720), 5.5,Size (1280,720), LeftROI, true);
  //   initUndistortRectifyMap(intrinsic_matrix_left, distCoeff_left, Mat::eye(3, 3, CV_8U), newmat_left, Size (1280,720), CV_32FC1, map1_left, map2_left);
  //   b.clear();
  //   distCoeff_left.clear();
  //   intrinsic_matrix_left.release();
    Mat src1, temp1, cameraFrame1, subt, gray1,gray2;
	cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(original_image, enc::BGR8);
	}
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("videofeed::igvc_IPM.cpp::cv_bridge exception: %s", e.what());
        return;
    }

    src1 = cv_ptr->image;
    //namedWindow("test_left"+cam,CV_WINDOW_AUTOSIZE);
	
	remap(src1, temp1, map1_left, map2_left, CV_INTER_LINEAR);
	resize(temp1, temp1, Size (scale*1280,scale*720));
	temp2 = temp1(Rect(0,40,640,440));
	// p1=removeblue(temp1,"L");
    waitKey(1);
}
void rightimage(const sensor_msgs::ImageConstPtr& original_image)
{
	cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(original_image, enc::BGR8);
	}
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("videofeed::igvc_IPM.cpp::cv_bridge exception: %s", e.what());
        return;
    }

    src2 = cv_ptr->image;
    //namedWindow("test_left"+cam,CV_WINDOW_AUTOSIZE);
	
//	remap(src2, temp2, map1_left, map2_left, CV_INTER_LINEAR);
    temp3=src2;
	resize(temp3, temp3, Size (scale*1280,scale*720));
	//temp2 = temp1(Rect(0,40,640,440));
	p2=removeblue(temp3,"R");
	distance();
    waitKey(1);
}

int main(int argc, char **argv)
{	
    ros::init(argc, argv, "Lane_D");
	ros::NodeHandle nh1;
	// ros::NodeHandle nh2;

	image_transport::ImageTransport it1(nh1);
	// image_transport::ImageTransport it2(nh2);

	image_transport::Subscriber sub_left = it1.subscribe("/camera1/image_raw", 1, leftimage);
	//image_transport::Subscriber sub_right = it2.subscribe("/camera2/usb_cam2/image_raw", 1, rightimage);
	//image_transport::Subscriber sub_right = it.subscribe("/camera3/image_raw", 1, rightimage);

	//pub_Lanedata = nh.advertise<nav_msgs::OccupancyGrid>("/Lane_Occupancy_Grid", 1);
//	pub_left = it.advertise("/camera/usb_cam1/image_raw1", 1);
	ros::Rate loop_rate(20);
	std::ifstream matleft("/home/anish/catkin_ws/src/vatsal/src/intrinsic_matrix_left.txt",std::ios::in);
	std::ifstream distleft("/home/anish/catkin_ws/src/vatsal/src/distCoeff_left.txt",std::ios::in);
	// Rect* LeftROI;
	std::vector<double> a;
	std::vector<double> distCoeff_left;
	 double num1 = 0.0;
	while (matleft >> num1) {
        a.push_back(num1);
    }
    double num2 = 0.0;
    while (distleft >> num2) {
        distCoeff_left.push_back(num2);
    }
    matleft.close();
    distleft.close();
    Mat intrinsic_matrix_left = (Mat_<double>(3,3) << a[0], a[1], a[2], a[3],a[4], a[5], a[6], a[7], a[8]);
    Mat newmat_left = getOptimalNewCameraMatrix(intrinsic_matrix_left, distCoeff_left,Size (1280,720), 5.5,Size (1280,720), LeftROI, true);
    initUndistortRectifyMap(intrinsic_matrix_left, distCoeff_left, Mat::eye(3, 3, CV_8U), newmat_left, Size (1280,720), CV_32FC1, map1_left, map2_left);
    a.clear();
    distCoeff_left.clear();
    newmat_left.release();
    intrinsic_matrix_left.release();


	// std::ifstream matright("/home/vatsal/catkin_ws/src/vatsal/src/intrinsic_matrix_right.txt",std::ios::in);
	// std::ifstream distright("/home/vatsal/catkin_ws/src/vatsal/src/distCoeff_right",std::ios::in);
	

	while(ros::ok())
	{	
		//begin = ros::Time::now().toSec();
		ros::spinOnce();
		//end = ros::Time::now().toSec();
		//cout<< end - begin <<endl;
		//final_grid.release();
		loop_rate.sleep();
		
	}

	ROS_INFO("videofeed::occupancygrid.cpp::No error.");

}