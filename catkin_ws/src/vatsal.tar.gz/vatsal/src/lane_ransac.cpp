// #include <opencv2/core.hpp>
// #include <opencv2/highgui.hpp>
// #include "opencv2/imgproc.hpp"
// #include <opencv2/core/utility.hpp>
// #include "opencv2/imgcodecs/imgcodecs.hpp"

// #include <stdio.h>
// #include <string.h>
// #include <iostream>
// #include "stdlib.h"
// #include <math.h>
#include "image_properties.h"
//ros libraries
#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "nav_msgs/OccupancyGrid.h"
#include <iostream>
#include <vector>
#include <math.h>
#include <string>
#include <fstream>
#include <algorithm>
#include </home/anish/Downloads/GRANSAC/include/GRANSAC.hpp>
#include </home/anish/Downloads/GRANSAC/include/AbstractModel.hpp>
#include </home/anish/Downloads/GRANSAC/examples/QuadraticModel.hpp>
//#include </home/anish/Downloads/GRANSAC/examples/CubicModel.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
#include <stdio.h>
#include <utility>
#include <opencv2/xfeatures2d.hpp>
#include "opencv2/features2d.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/calib3d/calib3d.hpp"

using namespace cv;
using namespace std;
namespace enc = sensor_msgs::image_encodings;

ros::Subscriber sub;
image_transport::Publisher lane_ransac;

int aux=0, tau=3, thresh=30;
int lane_dist=3,iterations=1,min_score=100;
Mat src;
std::vector<std::vector<Point> > contours_blue;
std::vector<Vec4i> hierarchy_blue;
std::vector<std::vector<Point> > contours;
std::vector<Vec4i> hierarchy;

vector <vector<Point> > endpoints;
int hue_low = 0;
int hue_high = 75;
int sat_low = 0;
int sat_high = 100;
int val_low = 128;
int val_high = 255;
Scalar avg, stddev, avg2;

GRANSAC::VPFloat Slope(int x0, int y0, int x1, int y1)
{
    return (GRANSAC::VPFloat)(y1 - y0) / (x1 - x0);
}
bool less_by_y(const cv::Point& lhs, const cv::Point& rhs)
{
  return lhs.y < rhs.y;
}
void DrawFullLine(cv::Mat& img, cv::Point a, cv::Point b, cv::Scalar color, int LineWidth)
{
    GRANSAC::VPFloat slope = Slope(a.x, a.y, b.x, b.y);

    cv::Point p(0, 0), q(img.cols, img.rows);

    p.y = -(a.x - p.x) * slope + a.y;
    q.y = -(b.x - q.x) * slope + b.y;

    cv::line(img, a,b, color, LineWidth, 8, 0);
}

void show_histogram(Mat gray, String histname){
      int histSize = 256;

  /// Set the ranges ( for B,G,R) )
  float range[] = { 1, 256 } ;
  const float* histRange = { range };

  bool uniform = true; bool accumulate = false;

  Mat b_hist, g_hist, r_hist;

  /// Compute the histograms:
  calcHist( &gray, 1, 0, Mat(), b_hist, 1, &histSize, &histRange, uniform, accumulate );

  // Draw the histograms for B, G and R
  int hist_w = 512; int hist_h = 400;
  int bin_w = cvRound( (double) hist_w/histSize );

  Mat histImage( hist_h, hist_w, CV_8UC3, Scalar( 0,0,0) );

  /// Normalize the result to [ 0, histImage.rows ]
  normalize(b_hist, b_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat() );

  /// Draw for each channel
  for( int i = 1; i < histSize; i++ )
  {
      line( histImage, Point( bin_w*(i-1), hist_h - cvRound(b_hist.at<float>(i-1)) ) ,
                       Point( bin_w*(i), hist_h - cvRound(b_hist.at<float>(i)) ),
                       Scalar( 255, 0, 0), 2, 8, 0  );
  }

  /// Display
  namedWindow(histname, CV_WINDOW_AUTOSIZE );
  imshow(histname, histImage );
}

Mat lane_filter_image(Mat src){
      //cvtColor(temp3,temp3,CV_RGB2GRAY);
    Mat dst=Mat::zeros(src.rows, src.cols, CV_8U);
    Mat result;
    // dst= Mat.zeros(temp3.rows(), temp3.cols(), CV_8U);
    namedWindow("controls2",CV_WINDOW_AUTOSIZE);
    createTrackbar("tau","controls2", &tau, 100);
    tau = getTrackbarPos("tau","controls2");
    createTrackbar("thresh","controls2", &thresh, 255);
    thresh = getTrackbarPos("thresh","controls2");
    // thresh = getTrackbarPos("thresh","lane");
    //while(1){
    for(int j=0; j<src.rows; j++){

        unsigned char* ptRowSrc = src.ptr<uchar>(j);
        unsigned char* ptRowDst = dst.ptr<uchar>(j);

        for(int i = tau; i< src.cols-tau; i++){
            if(ptRowSrc[i]!=0){
                aux = 2*ptRowSrc[i];
                aux += -ptRowSrc[i-tau];
                aux += -ptRowSrc[i+tau];
                aux += -2*abs((int)(ptRowSrc[i-tau]-ptRowSrc[i+tau]));
                //aux=aux/2;
                aux = (aux<0)?(0):(aux);
                aux = (aux>255)?(255):(aux);

                ptRowDst[i] = (unsigned char)aux;
            }
        }

    }
    //medianBlur(dst, dst, 5);
    Mat thresh_lane=dst>thresh;
    //show_histogram(thresh_lane, "lane_hist");
  //   double sumhist = sum(dst).val[0];
  //   double limit = 0.3*sumhist;

  //   int histSize = 256;

  // /// Set the ranges ( for B,G,R) )
  // float range[] = { 1, 256 } ;
  // const float* histRange = { range };

  // bool uniform = true; bool accumulate = false;

  // Mat b_hist;

  // // /// Compute the histograms:
  // calcHist( &dst, 1, 0, Mat(), b_hist, 1, &histSize, &histRange, uniform, accumulate );
  // thresh=255;
  // float num=0;
  // int i=0;
  //   while(limit>0){ 
  //       i++;
  //       //cout<<i<<" ";       
  //       num=thresh*b_hist.at<float>(thresh);
  //       limit=limit-num;
  //       thresh--;
  //       //cout<<num<<" "<<limit<<" "<<thresh<<endl;
  //   }
  //   cout<<thresh<<" ";
  //   result=dst>thresh;
  //   imshow("lane2",result);
    //show_histogram(result, "lane_hist2");
    result=dst>thresh;
    return result;
}

void ransac_fit(const sensor_msgs::ImageConstPtr& original_image){
    Mat temp4;
    int area, ksize;
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(original_image, enc::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("videofeed::igvc_IPM.cpp::cv_bridge exception: %s", e.what());
        return;
    }
    src = cv_ptr->image;
    namedWindow("controls",CV_WINDOW_AUTOSIZE);
    // const Point* ppt[1] = { rook_points[0] };
    int npt[] = { 4 };
    vector<Mat> channels, channels2;
    Mat frame,bw, sunlight,sunhsv, gray, bw_dilated, bw_eroded, sunlight_boundary;
    src=src(Rect(0,0*src.rows,src.cols,0.8*src.rows));
    cvtColor(src, frame, CV_BGR2Lab);
    cvtColor(src, gray, CV_BGR2GRAY);
    namedWindow("test_right",CV_WINDOW_AUTOSIZE);
    createTrackbar("hue_low","test_right", &hue_low, 179);
    createTrackbar("hue_high","test_right", &hue_high, 179);
    createTrackbar("sat_low","test_right", &sat_low, 255);
    createTrackbar("sat_high","test_right", &sat_high, 255);
    createTrackbar("val_low","test_right", &val_low, 255);
    createTrackbar("val_high","test_right", &val_high, 255);
    hue_low = getTrackbarPos("hue_low","test_right");
    hue_high = getTrackbarPos("hue_high","test_right");
    sat_low = getTrackbarPos("sat_low","test_right");
    sat_high = getTrackbarPos("sat_high","test_right");
    val_low = getTrackbarPos("val_low","test_right");
    val_high = getTrackbarPos("val_high","test_right");

    inRange(frame,Scalar(hue_low,sat_low,val_low),Scalar(hue_high,sat_high,val_high),bw);//detects blue
    imshow("Sunlight blobs",bw);

    int dilation_size=1;
    Mat element = getStructuringElement( MORPH_RECT,
                                       Size( 2*dilation_size + 1, 2*dilation_size+1 ),
                                       Point( dilation_size, dilation_size ) );
    dilate( bw,bw_dilated, element );
    erode( bw,bw_eroded, element );
    sunlight_boundary=bw_dilated-bw_eroded;
    imshow("Lab",frame);
    split(frame, channels);
    src.copyTo(sunlight, bw);
    Mat editted, otsu,sunlight_gray, otsu_sunlight, otsu_editted;
    meanStdDev(gray, avg, stddev,bw);
    meanStdDev(gray, avg2, stddev,255-bw);
    gray.copyTo(sunlight_gray, bw);
    
    editted=gray-(avg[0]-avg2[0])*sunlight_gray/avg[0];
    equalizeHist( editted, editted );
    //editted.setTo(Scalar(int(avg2[0]),0,0),bw);
    imshow("Editted",editted);
    threshold(gray,otsu, 1, 255, CV_THRESH_BINARY | CV_THRESH_OTSU);
    meanStdDev(gray, avg, stddev,otsu);
    meanStdDev(gray, avg2, stddev,255-otsu);
    gray.copyTo(otsu_sunlight, otsu);
    
    otsu_editted=gray-(avg[0]-avg2[0])*otsu_sunlight/avg[0];
    equalizeHist( otsu_editted, otsu_editted );
    imshow("otsu",otsu);
    imshow("otsu_editted",otsu_editted);
    imshow("sunlight", sunlight);
    cvtColor(sunlight, sunhsv, CV_BGR2Lab);
    imshow("sunhsv", sunhsv);
    //src=editted;
    //src=sunlight;
    if(src.rows>0){
    //cvtColor(src,src,CV_BGR2GRAY);
    //show_histogram(src,"src_hist");
    imshow("Original",src);
    Mat yellow=channels[0]<40;
    yellow=yellow>20;
    // imshow("Yellow",yellow);
    // imshow("H",channels[0]);
    // imshow("S",channels[1]);
    // imshow("V",channels[2]);
    //src=(0.5*channels[0]+0.5*channels[2]);
    //equalizeHist( src, src );

    imshow("Filtered",src);
    
    src=lane_filter_image(src);

    //resize(src,src,Size(0.5*src.cols,0.5*src.rows),CV_INTER_LINEAR);
    Mat result= Mat::zeros(src.size(), CV_8UC1);
    Mat temp3= Mat::zeros(src.size(), CV_8UC1);
    int dilation_size=1;
    Mat element = getStructuringElement( MORPH_RECT,
                                       Size( 2*dilation_size + 1, 2*dilation_size+1 ),
                                       Point( dilation_size, dilation_size ) );
    //erode( src,src, element );
    imshow("Lane filter",src);
    src-=sunlight_boundary;
    imshow("Lane filter without boundary",src);
    editted=lane_filter_image(editted);
    imshow("Lane without sunlight",editted);
    editted-=sunlight_boundary;
    imshow("Lane without sunlight boundary",editted);
    otsu_editted=lane_filter_image(otsu_editted);
    imshow("Lane without sunlight otsu",otsu_editted);
    otsu_editted-=sunlight_boundary;
    imshow("Lane without sunlight boundary otsu",otsu_editted);
    drawContours( src, contours_blue, -1, Scalar(0), -1);
    //rectangle(temp3, Point(150,370),Point(280,440), 0,-1);//280
    //fillPoly( temp3,ppt,npt,1,Scalar(0,0,0));
    //imshow("gauss",temp3);
        createTrackbar("ksize","controls", &ksize, 100);
    ksize = getTrackbarPos("ksize","controls");
    //medianBlur(src, temp4, ksize*2 + 1);
    temp4=src;
    findContours(temp4, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_NONE);
    Mat blank = Mat::zeros(temp4.rows, temp4.cols, CV_8UC1);
        createTrackbar("area","controls", &area, 100);
    area = getTrackbarPos("area","controls");
    for (int i = 0; i < contours.size(); ++i)
    {
        if (contourArea(contours[i]) >= area)
        {
            drawContours(blank, contours, i, Scalar(255),-1);
        }
    }
    imshow("Final_right",blank);
    src=blank;
    for(int n_lanes=0;n_lanes<2;n_lanes++){
    std::vector<std::shared_ptr<GRANSAC::AbstractParameter>> CandPoints;
    vector<Point> locations;   // output, locations of non-zero pixels
    findNonZero(src, locations);
    auto mmx = std::minmax_element(locations.begin(), locations.end(), less_by_y);

    for (int i = 0; i < locations.size(); ++i)
    {
        cv::Point Pt=locations[i];
        std::shared_ptr<GRANSAC::AbstractParameter> CandPt = std::make_shared<Point2D>(Pt.x, Pt.y);
        CandPoints.push_back(CandPt);
    }
    
    GRANSAC::RANSAC<Quadratic2DModel, 3> Estimator;
    //GRANSAC::RANSAC<Cubic2DModel, 4> Estimator;
    
        createTrackbar("lane_dist","controls", &lane_dist, 100);
    lane_dist = getTrackbarPos("lane_dist","controls");
        createTrackbar("iterations","controls", &iterations, 1000);
    iterations = getTrackbarPos("iterations","controls");
        createTrackbar("min_score","controls", &min_score, 1000);
    min_score = getTrackbarPos("min_score","controls");


    Estimator.Initialize(lane_dist,iterations); // Threshold, iterations
    int start = cv::getTickCount();
    Estimator.Estimate(CandPoints);
    int end = cv::getTickCount();
    std::cout << "RANSAC took: " << GRANSAC::VPFloat(end - start) / GRANSAC::VPFloat(cv::getTickFrequency()) * 1000.0 << " ms." << std::endl;

    auto BestInliers = Estimator.GetBestInliers();
    auto BestLine = Estimator.GetBestModel();
    GRANSAC::VPFloat BestScore = Estimator.GetBestScore();
    cout<<BestScore;
    if (BestLine && BestScore>min_score){
    std::vector<GRANSAC::VPFloat> Parameters =  Estimator.GetBestParameters();
    //cout<<Parameters[0]<<" "<<Parameters[1]<<" "<<Parameters[2]<<endl;
    int start=0;
    for(int i=mmx.first->y;i<mmx.second->y;i++){
        double x=Parameters[0]*i*i + Parameters[1]*i + Parameters[2];
        //double x=Parameters[0]*i*i*i + Parameters[1]*i*i + Parameters[2]*i + Parameters[3];
        if(x>0 && x<src.cols){
            if(start==0){
                start=1;
                endpoints[n_lanes][0]=Point(x,i);
            }
            cv::circle(result, Point(x,i), 1, cv::Scalar(255,255,255), -1);
            cv::circle(src, Point(x,i), 2*lane_dist, cv::Scalar(0,0,0), -1);
            endpoints[n_lanes][1]=Point(x,i);
        }

    }

}
}

    // if (BestInliers.size() > 0)
    // {
    //     for (auto& Inlier : BestInliers)
    //     {
    //         auto RPt = std::dynamic_pointer_cast<Point2D>(Inlier);
    //         cv::Point Pt(floor(RPt->m_Point2D[0]), floor(RPt->m_Point2D[1]));
    //         cv::circle(result, Pt, 1, cv::Scalar(255,255,255), -1);
    //     }
    // }

    // auto BestLine = Estimator.GetBestModel();

    // if (BestLine)
    // {
    //     auto BestLinePt1 = std::dynamic_pointer_cast<Point2D>(BestLine->GetModelParams()[0]);
    //     auto BestLinePt2 = std::dynamic_pointer_cast<Point2D>(BestLine->GetModelParams()[1]);
    //     auto BestLinePt3 = std::dynamic_pointer_cast<Point2D>(BestLine->GetModelParams()[2]);
        
    //     if (BestLinePt1 && BestLinePt2 && BestLinePt3)
    //     {
    //         cv::Point Pt1(BestLinePt1->m_Point2D[0], BestLinePt1->m_Point2D[1]);
    //         cv::Point Pt2(BestLinePt2->m_Point2D[0], BestLinePt2->m_Point2D[1]);
    //         cv::Point Pt3(BestLinePt3->m_Point2D[0], BestLinePt3->m_Point2D[1]);
    //         //std::cerr<<Pt3;
    //         DrawFullLine(result, Pt1, Pt2, cv::Scalar(0, 0, 255), 2);
    //         DrawFullLine(result, Pt2, Pt3, cv::Scalar(0, 0, 255), 2);
    //         DrawFullLine(result, Pt1, Pt3, cv::Scalar(0, 0, 255), 2);
    //     }
    // }

    imshow("RANSAC",result);
    cv_ptr->image = result;
    lane_ransac.publish(cv_ptr->toImageMsg());
    waitKey(1);
}
}

int main(int argc, char **argv)
{   
    ros::init(argc, argv, "Lane_D");
    ros::NodeHandle nh1;

    image_transport::ImageTransport it1(nh1);
    image_transport::Subscriber sub = it1.subscribe("/camera/lane", 1, ransac_fit);
    lane_ransac = it1.advertise("/camera/lane_ransac", 1);

    ros::Rate loop_rate(20);

    while(ros::ok())
    {   
        ros::spinOnce();
        loop_rate.sleep();        
    }
    ROS_INFO("videofeed::occupancygrid.cpp::No error.");

}