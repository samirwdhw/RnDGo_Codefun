#include "image_properties.h"
//ros libraries
#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "nav_msgs/OccupancyGrid.h"
#include "nav_msgs/Path.h"
#include "std_msgs/Int8MultiArray.h"
#include <iostream>
#include <vector>
#include <math.h>
#include <string>
#include <fstream>
#include <algorithm>
#include </home/anish/Downloads/GRANSAC/include/GRANSAC.hpp>
#include </home/anish/Downloads/GRANSAC/include/AbstractModel.hpp>
#include </home/anish/Downloads/GRANSAC/examples/QuadraticModel.hpp>
//#include </home/anish/Downloads/GRANSAC/examples/CubicModel.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
#include <stdio.h>
#include <utility>
#include <opencv2/xfeatures2d.hpp>
#include "opencv2/features2d.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/calib3d/calib3d.hpp"

using namespace cv;
using namespace std;
namespace enc = sensor_msgs::image_encodings;

ros::Subscriber sub;
image_transport::Publisher lane_ransac;

int aux=0, tau=3, thresh=30;
int lane_dist=3,iterations=10,min_score=10;
Mat src;
std::vector<std::vector<Point> > contours_blue;
std::vector<Vec4i> hierarchy_blue;

int hue_low = 0;
int hue_high = 75;
int sat_low = 0;
int sat_high = 100;
int val_low = 128;
int val_high = 255;
Scalar avg, stddev, avg2;

string WINDOW = "Occupancy-Gird";

nav_msgs::OccupancyGrid Final_Grid;

nav_msgs::Path gui_path1;

ros::Subscriber sub_Lanedata_left;
ros::Subscriber sub_Lanedata_right;

ros::Publisher pub_Lanedata;
ros::Publisher path_pub;
image_transport::Publisher pub_ipm;
//ros::Publisher map_pub,blown_map_pub;

std::vector<std::vector<Point> > Lane_points_left;
std::vector<std::vector<Point> > Lane_points_right;

Mat src_left, src_right,dst,labels,dst2;
Mat roi, final_grid;
int iterations_dilate = 1;
int ker_size_dilate = 2;
int area = 1;
double compactness;
Mat kernel_dilate;
std::vector<std::vector<Point> > contours;
std::vector<std::vector<Point> > extremes;
std::vector<Vec4i> hierarchy;
std::vector<Point2f> Lanepoints;

GRANSAC::VPFloat Slope(int x0, int y0, int x1, int y1)
{
    return (GRANSAC::VPFloat)(y1 - y0) / (x1 - x0);
}
bool less_by_y(const cv::Point& lhs, const cv::Point& rhs)
{
  return lhs.y < rhs.y;
}
void DrawFullLine(cv::Mat& img, cv::Point a, cv::Point b, cv::Scalar color, int LineWidth)
{
    GRANSAC::VPFloat slope = Slope(a.x, a.y, b.x, b.y);

    cv::Point p(0, 0), q(img.cols, img.rows);

    p.y = -(a.x - p.x) * slope + a.y;
    q.y = -(b.x - q.x) * slope + b.y;

    cv::line(img, a,b, color, LineWidth, 8, 0);
}

void show_histogram(Mat gray, String histname){
      int histSize = 256;

  /// Set the ranges ( for B,G,R) )
  float range[] = { 1, 256 } ;
  const float* histRange = { range };

  bool uniform = true; bool accumulate = false;

  Mat b_hist, g_hist, r_hist;

  /// Compute the histograms:
  calcHist( &gray, 1, 0, Mat(), b_hist, 1, &histSize, &histRange, uniform, accumulate );

  // Draw the histograms for B, G and R
  int hist_w = 512; int hist_h = 400;
  int bin_w = cvRound( (double) hist_w/histSize );

  Mat histImage( hist_h, hist_w, CV_8UC3, Scalar( 0,0,0) );

  /// Normalize the result to [ 0, histImage.rows ]
  normalize(b_hist, b_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat() );

  /// Draw for each channel
  for( int i = 1; i < histSize; i++ )
  {
      line( histImage, Point( bin_w*(i-1), hist_h - cvRound(b_hist.at<float>(i-1)) ) ,
                       Point( bin_w*(i), hist_h - cvRound(b_hist.at<float>(i)) ),
                       Scalar( 255, 0, 0), 2, 8, 0  );
  }

  /// Display
  namedWindow(histname, CV_WINDOW_AUTOSIZE );
  imshow(histname, histImage );
}

Mat lane_filter_image(Mat src){
      //cvtColor(temp3,temp3,CV_RGB2GRAY);
    Mat dst=Mat::zeros(src.rows, src.cols, CV_8U);
    Mat result=Mat::zeros(src.rows, src.cols, CV_8U);
    // dst= Mat.zeros(temp3.rows(), temp3.cols(), CV_8U);
    namedWindow(WINDOW,CV_WINDOW_AUTOSIZE);
    createTrackbar("tau",WINDOW, &tau, 100);
    tau = getTrackbarPos("tau",WINDOW);
    createTrackbar("thresh",WINDOW, &thresh, 255);
    thresh = getTrackbarPos("thresh",WINDOW);
    // thresh = getTrackbarPos("thresh","lane");
    //while(1){
    for(int j=0; j<src.rows; j++){

        unsigned char* ptRowSrc = src.ptr<uchar>(j);
        unsigned char* ptRowDst = dst.ptr<uchar>(j);

        for(int i = tau; i< src.cols-tau; i++){
            if(ptRowSrc[i]!=0){
                aux = 2*ptRowSrc[i];
                aux += -ptRowSrc[i-tau];
                aux += -ptRowSrc[i+tau];
                aux += -2*abs((int)(ptRowSrc[i-tau]-ptRowSrc[i+tau]));
                //aux=aux/2;
                aux = (aux<0)?(0):(aux);
                aux = (aux>255)?(255):(aux);

                ptRowDst[i] = (unsigned char)aux;
            }
        }

    }
    //medianBlur(dst, dst, 5);
    //Mat thresh_lane=dst>thresh;
    //show_histogram(thresh_lane, "lane_hist");
  //   double sumhist = sum(dst).val[0];
  //   double limit = 0.3*sumhist;

  //   int histSize = 256;

  // /// Set the ranges ( for B,G,R) )
  // float range[] = { 1, 256 } ;
  // const float* histRange = { range };

  // bool uniform = true; bool accumulate = false;

  // Mat b_hist;

  // // /// Compute the histograms:
  // calcHist( &dst, 1, 0, Mat(), b_hist, 1, &histSize, &histRange, uniform, accumulate );
  // thresh=255;
  // float num=0;
  // int i=0;
  //   while(limit>0){ 
  //       i++;
  //       //cout<<i<<" ";       
  //       num=thresh*b_hist.at<float>(thresh);
  //       limit=limit-num;
  //       thresh--;
  //       //cout<<num<<" "<<limit<<" "<<thresh<<endl;
  //   }
  //   cout<<thresh<<" ";
  //   result=dst>thresh;
  //   imshow("lane2",result);
    //show_histogram(result, "lane_hist2");
    result=dst>thresh;
    return result;
}

void ransac_fit(const sensor_msgs::ImageConstPtr& original_image){
    Mat temp4;
    int area, ksize;
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(original_image, enc::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("videofeed::igvc_IPM.cpp::cv_bridge exception: %s", e.what());
        return;
    }
    src = cv_ptr->image;
    
    //namedWindow(WINDOW,CV_WINDOW_AUTOSIZE);
    // const Point* ppt[1] = { rook_points[0] };
    int npt[] = { 4 };
    vector<Mat> channels, channels2;
    Mat frame,bw, sunlight,sunhsv, gray, bw_dilated, bw_eroded, sunlight_boundary;
    //src=src(Rect(0,0*src.rows,src.cols,0.8*src.rows));
    //cvtColor(src, frame, CV_BGR2HSV);
    cvtColor(src, gray, CV_BGR2GRAY);
    // namedWindow(WINDOW,CV_WINDOW_AUTOSIZE);
    // createTrackbar("hue_low",WINDOW, &hue_low, 179);
    // createTrackbar("hue_high",WINDOW, &hue_high, 179);
    // createTrackbar("sat_low",WINDOW, &sat_low, 255);
    // createTrackbar("sat_high",WINDOW, &sat_high, 255);
    // createTrackbar("val_low",WINDOW, &val_low, 255);
    // createTrackbar("val_high",WINDOW, &val_high, 255);
    // hue_low = getTrackbarPos("hue_low",WINDOW);
    // hue_high = getTrackbarPos("hue_high",WINDOW);
    // sat_low = getTrackbarPos("sat_low",WINDOW);
    // sat_high = getTrackbarPos("sat_high",WINDOW);
    // val_low = getTrackbarPos("val_low",WINDOW);
    // val_high = getTrackbarPos("val_high",WINDOW);

    // inRange(frame,Scalar(hue_low,sat_low,val_low),Scalar(hue_high,sat_high,val_high),bw);//detects blue
    // imshow("Sunlight blobs",bw);

    // int dilation_size=1;
    // Mat element = getStructuringElement( MORPH_RECT,
    //                                    Size( 2*dilation_size + 1, 2*dilation_size+1 ),
    //                                    Point( dilation_size, dilation_size ) );
    // dilate( bw,bw_dilated, element );
    // erode( bw,bw_eroded, element );
    // sunlight_boundary=bw_dilated-bw_eroded;
    // imshow("HSV",frame);
    // split(frame, channels);
    // src.copyTo(sunlight, bw);
    // Mat editted, otsu,sunlight_gray, otsu_sunlight, otsu_editted;
    // meanStdDev(gray, avg, stddev,bw);
    // meanStdDev(gray, avg2, stddev,255-bw);
    // gray.copyTo(sunlight_gray, bw);
    
    // editted=gray-(avg[0]-avg2[0])*sunlight_gray/avg[0];
    // equalizeHist( editted, editted );
    // //editted.setTo(Scalar(int(avg2[0]),0,0),bw);
    // imshow("Editted",editted);
    // threshold(channels[2],otsu, 1, 255, CV_THRESH_BINARY | CV_THRESH_OTSU);
    // meanStdDev(gray, avg, stddev,otsu);
    // meanStdDev(gray, avg2, stddev,255-otsu);
    // gray.copyTo(otsu_sunlight, otsu);
    
    // otsu_editted=gray-(avg[0]-avg2[0])*otsu_sunlight/avg[0];
    // equalizeHist( otsu_editted, otsu_editted );
    // imshow("otsu",otsu);
    // imshow("otsu_editted",otsu_editted);
    // imshow("sunlight", sunlight);
    // cvtColor(sunlight, sunhsv, CV_BGR2HSV);
    // imshow("sunhsv", sunhsv);
    //src=editted;
    //src=sunlight;
    src=gray;
    if(src.rows>0){
    //cvtColor(src,src,CV_BGR2GRAY);
    //show_histogram(src,"src_hist");
    imshow("Original",src);
    // Mat yellow=channels[0]<40;
    // yellow=yellow>20;
    // imshow("Yellow",yellow);
    // imshow("H",channels[0]);
    // imshow("S",channels[1]);
    // imshow("V",channels[2]);
    //src=(0.5*channels[0]+0.5*channels[2]);
    //equalizeHist( src, src );

    //imshow("Filtered",src);
    
    src=lane_filter_image(src);

    //resize(src,src,Size(0.5*src.cols,0.5*src.rows),CV_INTER_LINEAR);
    Mat result= Mat::zeros(src.size(), CV_8UC1);
    Mat temp3= Mat::zeros(src.size(), CV_8UC1);
    int dilation_size=1;
    Mat element = getStructuringElement( MORPH_RECT,
                                       Size( 2*dilation_size + 1, 2*dilation_size+1 ),
                                       Point( dilation_size, dilation_size ) );
    dilate( src,src, element );
    //Mat sum=src+sunlight_boundary;
    imshow("Lane filter",src);

    // subtract(src,sunlight_boundary,src);
    // imshow("Lane filter without boundary",src);
    // editted=lane_filter_image(editted);
    // imshow("Lane without sunlight",editted);
    // subtract(editted,sunlight_boundary,editted);
    // imshow("Lane without sunlight boundary",editted);
    // otsu_editted=lane_filter_image(otsu_editted);
    // imshow("Lane without sunlight otsu",otsu_editted);
    // subtract(otsu_editted,sunlight_boundary,otsu_editted);
    // imshow("Lane without sunlight boundary otsu",otsu_editted);
    // drawContours( src, contours_blue, -1, Scalar(0), -1);
    //rectangle(temp3, Point(150,370),Point(280,440), 0,-1);//280
    //fillPoly( temp3,ppt,npt,1,Scalar(0,0,0));
    //imshow("gauss",temp3);
    // createTrackbar("ksize",WINDOW, &ksize, 100);
    // ksize = getTrackbarPos("ksize",WINDOW);
    // //medianBlur(src, temp4, ksize*2 + 1);
    temp4=src;
    findContours(temp4, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_NONE);
    extremes=contours;
    //extremes.clear();
    Mat blank = Mat::zeros(temp4.rows, temp4.cols, CV_8UC1);
        createTrackbar("area",WINDOW, &area, 100);
    area = getTrackbarPos("area",WINDOW);
    for (int i = 0; i < contours.size(); ++i)
    {
        if (contourArea(contours[i]) >= area)
        {
            drawContours(blank, contours, i, Scalar(255),-1);
        }
    }
    imshow("Final_right",blank);
    src=blank;
    for(int n_lanes=0;n_lanes<2;n_lanes++)
    {
    std::vector<std::shared_ptr<GRANSAC::AbstractParameter>> CandPoints;
    vector<Point> locations;   // output, locations of non-zero pixels
    findNonZero(src, locations);
    auto mmx = std::minmax_element(locations.begin(), locations.end(), less_by_y);

    for (int i = 0; i < locations.size(); ++i)
    {
        cv::Point Pt=locations[i];
        std::shared_ptr<GRANSAC::AbstractParameter> CandPt = std::make_shared<Point2D>(Pt.x, Pt.y);
        CandPoints.push_back(CandPt);
    }
    
    GRANSAC::RANSAC<Quadratic2DModel, 3> Estimator;
    //GRANSAC::RANSAC<Cubic2DModel, 4> Estimator;
    
        createTrackbar("lane_dist",WINDOW, &lane_dist, 100);
    lane_dist = getTrackbarPos("lane_dist",WINDOW);
        createTrackbar("iterations",WINDOW, &iterations, 1000);
    iterations = getTrackbarPos("iterations",WINDOW);
        createTrackbar("min_score",WINDOW, &min_score, 1000);
    min_score = getTrackbarPos("min_score",WINDOW);


    Estimator.Initialize(lane_dist,iterations); // Threshold, iterations
    int start = cv::getTickCount();
    Estimator.Estimate(CandPoints);
    int end = cv::getTickCount();
    std::cout << "RANSAC took: " << GRANSAC::VPFloat(end - start) / GRANSAC::VPFloat(cv::getTickFrequency()) * 1000.0 << " ms." << std::endl;

    auto BestInliers = Estimator.GetBestInliers();
    auto BestLine = Estimator.GetBestModel();
    GRANSAC::VPFloat BestScore = Estimator.GetBestScore();
    cout<<"Best Score: "<<BestScore<< endl;
    if (BestLine && BestScore>min_score)
    {
      std::vector<GRANSAC::VPFloat> Parameters =  Estimator.GetBestParameters();
      //cout<<Parameters[0]<<" "<<Parameters[1]<<" "<<Parameters[2]<<endl;
      int start=0;
      for(int i=mmx.first->y;i<mmx.second->y;i++){
          double x=Parameters[0]*i*i + Parameters[1]*i + Parameters[2];
          //double x=Parameters[0]*i*i*i + Parameters[1]*i*i + Parameters[2]*i + Parameters[3];
          if(x>0 && x<src.cols){
              if(start==0){
                  start=1;
                  extremes[n_lanes][0]=Point(x,i);
              }
              cv::circle(result, Point(x,i), 1, cv::Scalar(255,255,255), -1);
              cv::circle(src, Point(x,i), 2*lane_dist, cv::Scalar(0,0,0), -1);
              extremes[n_lanes][1]=Point(x,i);
          }

      }

  }
}

    // if (BestInliers.size() > 0)
    // {
    //     for (auto& Inlier : BestInliers)
    //     {
    //         auto RPt = std::dynamic_pointer_cast<Point2D>(Inlier);
    //         cv::Point Pt(floor(RPt->m_Point2D[0]), floor(RPt->m_Point2D[1]));
    //         cv::circle(result, Pt, 1, cv::Scalar(255,255,255), -1);
    //     }
    // }

    // auto BestLine = Estimator.GetBestModel();

    // if (BestLine)
    // {
    //     auto BestLinePt1 = std::dynamic_pointer_cast<Point2D>(BestLine->GetModelParams()[0]);
    //     auto BestLinePt2 = std::dynamic_pointer_cast<Point2D>(BestLine->GetModelParams()[1]);
    //     auto BestLinePt3 = std::dynamic_pointer_cast<Point2D>(BestLine->GetModelParams()[2]);
        
    //     if (BestLinePt1 && BestLinePt2 && BestLinePt3)
    //     {
    //         cv::Point Pt1(BestLinePt1->m_Point2D[0], BestLinePt1->m_Point2D[1]);
    //         cv::Point Pt2(BestLinePt2->m_Point2D[0], BestLinePt2->m_Point2D[1]);
    //         cv::Point Pt3(BestLinePt3->m_Point2D[0], BestLinePt3->m_Point2D[1]);
    //         //std::cerr<<Pt3;
    //         DrawFullLine(result, Pt1, Pt2, cv::Scalar(0, 0, 255), 2);
    //         DrawFullLine(result, Pt2, Pt3, cv::Scalar(0, 0, 255), 2);
    //         DrawFullLine(result, Pt1, Pt3, cv::Scalar(0, 0, 255), 2);
    //     }
    // }
    dst=result;
    imshow("RANSAC",result);
    cv_ptr->image = result;
    lane_ransac.publish(cv_ptr->toImageMsg());
    waitKey(1);
  }
}

void endprocessing()
{

      nav_msgs::Path gui_path;
      geometry_msgs::PoseStamped pose;
      // std::vector<geometry_msgs::PoseStamped> plan;
    for (int i=0; i<extremes.size(); i++){
          pose.pose.position.x = extremes[i][0].x;
          pose.pose.position.y = extremes[i][0].y;
          pose.pose.position.z = 0.0;
          pose.pose.orientation.x = 0.0;
          pose.pose.orientation.y = 0.0;
          pose.pose.orientation.z = 0.0;
          pose.pose.orientation.w = 1.0;
          //plan.push_back(pose);
          gui_path.poses.push_back(pose);
        }
//publishing bottom


      // std::vector<geometry_msgs::PoseStamped> plan1;
    for (int i=0; i<extremes.size(); i++){
          pose.pose.position.x = extremes[i][1].x;
          pose.pose.position.y = extremes[i][1].y;
          pose.pose.position.z = 0.0;
          pose.pose.orientation.x = 0.0;
          pose.pose.orientation.y = 0.0;
          pose.pose.orientation.z = 0.0;
          pose.pose.orientation.w = 1.0;
          gui_path.poses.push_back(pose);
        }
        path_pub.publish(gui_path);
        gui_path.poses.clear();

    //Lanepoints.clear();




    Final_Grid.info.map_load_time = ros::Time::now();
    Final_Grid.header.frame_id = "lane";
    Final_Grid.info.resolution = (float)map_width/(100*(float)occ_grid_widthr);
    Final_Grid.info.width = 200;
    Final_Grid.info.height = 400;

    Final_Grid.info.origin.position.x = 0;
    Final_Grid.info.origin.position.y = 0;
    Final_Grid.info.origin.position.z = 0;

    Final_Grid.info.origin.orientation.x = 0;
    Final_Grid.info.origin.orientation.y = 0;
    Final_Grid.info.origin.orientation.z = 0;
    Final_Grid.info.origin.orientation.w = 1;



    for (int i = 0; i < dst.rows; ++i)
    {
        for (int j = 0; j < dst.cols; ++j)
        {
            if ( dst.at<uchar>(i,j) > 0)
            {
                //cout<<"r";
                Final_Grid.data.push_back(2);

            }
            else
                Final_Grid.data.push_back(dst.at<uchar>(i,j));
        }
    }
    pub_Lanedata.publish(Final_Grid);
    Final_Grid.data.clear();

}

int main(int argc, char **argv)
{
    
    
    ros::init(argc, argv, "Lane_Occupancy_Grid");
    ros::NodeHandle nh;
    
    image_transport::ImageTransport it(nh);

    image_transport::Publisher pub;
    
    
    image_transport::Subscriber sub_left = it.subscribe("/camera/lane", 1, ransac_fit);
    //image_transport::Subscriber sub_right = it.subscribe("/camera/image_raw3", 1, rightimage);

    pub = it.advertise("/camera/ipm", 1);

    cv::namedWindow(WINDOW, CV_WINDOW_AUTOSIZE);
    createTrackbar("iterations_dilate", WINDOW, &iterations_dilate, 10);
    createTrackbar("ker_size_dilate", WINDOW, &ker_size_dilate, 10);
    createTrackbar("area", WINDOW, &area, 200);
    //pub = it.advertise("/Lane_Occupancy_Grid", 1);
    pub_Lanedata = nh.advertise<nav_msgs::OccupancyGrid>("/Lane_Occupancy_Grid", 1);
    ros::Rate loop_rate(5);
//publishing top
      ros::NodeHandle p;
      path_pub = p.advertise<nav_msgs::Path>("/lane_coord", 1);

    
    // gui_path.poses.resize(plan.size());

    // if(!plan.empty()){
    //       gui_path.header.frame_id = 'map';
    //       gui_path.header.stamp = plan[0].header.stamp;
    // }

    // for(unsigned int i=0; i < plan.size(); i++){
    //       gui_path.poses[i] = plan[i];
    // }

//publishing bottom

    // gui_path1.poses.resize(plan1.size());

    // if(!plan1.empty()){
    //       gui_path1.header.frame_id = 'map';
    //       gui_path1.header.stamp = plan1[0].header.stamp;
    // }

    // for(unsigned int i=0; i < plan1.size(); i++){
    //       gui_path1.poses[i] = plan1[i];
    // }


    while(ros::ok())
    {   

    //begin = ros::Time::now().toSec();
    final_grid = Mat::zeros(Size(occ_grid_width, occ_grid_height), CV_8UC1);
    ros::spinOnce();
    final_grid = final_grid(Rect(150,0,200,400));
    //cvtColor(final_grid,final_grid,CV_GRAY2BGR);
    endprocessing();

    cvtColor(dst,dst2,CV_GRAY2BGR);
    sensor_msgs::ImagePtr msg = cv_bridge::CvImage(std_msgs::Header(), "bgr8", dst2).toImageMsg();
    pub.publish(msg);
    
    imshow(WINDOW, dst);
    //Final_Grid.data.clear();
    final_grid.release();
    loop_rate.sleep();
    //end = ros::Time::now().toSec();
    //cout<< end - begin <<endl;
    }

    ROS_INFO("videofeed::occupancygrid.cpp::No error.");
}