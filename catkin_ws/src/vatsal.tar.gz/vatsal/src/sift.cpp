#include "image_properties.h"
#include "opencv2/core.hpp"
#include "opencv2/features2d.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/xfeatures2d.hpp"
//ros libraries
#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "nav_msgs/OccupancyGrid.h"
//c++ libraries
#include <iostream>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <string>
#include <fstream>


using namespace std;
using namespace cv;
using namespace cv::xfeatures2d;

namespace enc = sensor_msgs::image_encodings;

  // int minHessian = 400;
  // Ptr<SURF> detector = SURF::create();
  // detector->setHessianThreshold(minHessian);
std::vector<KeyPoint> keypoints_1, keypoints_2;
Mat descriptors_1, descriptors_2;



/*
 * @function readme
 */
ros::Subscriber sub_Lanedata_left;
ros::Subscriber sub_Lanedata_right;
//Use method of ImageTransport to create image publisher
image_transport::Publisher pub_left;
image_transport::Publisher pub_right;

int bv = 60;
int c = 70;
int ksize = 1;
int area = 25;
int hue_low = 0;
int hue_high = 100;
int sat_low = 0;
int sat_high =100;
int val_low = 100;
int val_high = 255;
int circle_sensitivity=10;
int found=0;

// Rect* RightROI;
// Rect* LeftROI;
 Point p_left,p_right;

// float dpi=8;
// float cam_dist=0.8;
// float f=0.05;
// float x_left_prev=0,x_right_prev=0;
// float uncertainty=0;
// float y_error=0;

// std::vector<double> dist_arr;
// std::vector<std::vector<Point> > contours;
// std::vector<Vec4i> hierarchy;
// std::vector<std::vector<Point> > contours_blue;
// std::vector<Vec4i> hierarchy_blue;
// std::vector<std::vector<Point> > contours_red;
// std::vector<Vec4i> hierarchy_red;
// std::vector<std::vector<Point> > contours_orange;
// std::vector<Vec4i> hierarchy_orange;

Mat src,temp1,temp2,temp3,temp4,blank,dst,blue,map1_left,map2_left,map1_right,map2_right,src_right,gray1,gray2,diff;
vector<Mat> BGR;
Mat kernel_dilate;

  // int minHessian = 400;
   Ptr<SURF> detector = SURF::create();
   Mat img_matches,cropped1,cropped2,roi1,roi2;
   double mean_dist,disp,c_1,c_2;

double CalcMHWScore(vector<float> scores)
{
  double median;
  size_t size = scores.size();

  sort(scores.begin(), scores.end());

  if (size  % 2 == 0)
  {
      median = (scores[size / 2 - 1] + scores[size / 2]) / 2;
  }
  else 
  {
      median = scores[size / 2];
  }

  return median;
}

void sift()
{

  int minHessian = 400;
  float x1,x2;
  mean_dist=0;
  Ptr<SURF> detector = SURF::create();

  FlannBasedMatcher matcher;
  std::vector< DMatch > matches;
  std::vector< DMatch > good_matches;
  std::vector< float > disparity_array;
  detector->setHessianThreshold(minHessian);
  matches.clear();
  good_matches.clear();
  disparity_array.clear();

  matcher.match( descriptors_1, descriptors_2, matches );
  double max_dist = 0; double min_dist = 100;
  //-- Quick calculation of max and min distances between keypoints
  for( int i = 0; i < min(descriptors_1.rows,descriptors_2.rows); i++ )
  { double dist = matches[i].distance;

    if( dist < min_dist ) min_dist = dist;
    if( dist > max_dist ) max_dist = dist;
  }
  printf("-- Max dist : %f \n", max_dist );
  printf("-- Min dist : %f \n", min_dist );
  // printf("Min %d %d ",descriptors_1.rows,descriptors_2.rows);

   for( int i = 0; i < min(descriptors_1.rows,descriptors_2.rows); i++ )
  { if( matches[i].distance <= min(2*min_dist,0.05) )
    { good_matches.push_back( matches[i]); 
    	x1=keypoints_1[ matches[i].trainIdx ].pt.x;
    	x2=keypoints_2[ matches[i].trainIdx ].pt.x;
    	//mean_dist+=abs(x1-x2);
    	 disparity_array.push_back(x1-x2);
    }
  }

  // for(int i=0;i<disparity_array.size();i++)	printf("%f ",disparity_array.at(i));
  // mean_dist/=min(descriptors_1.rows,descriptors_2.rows);
  // mean_dist+=disp;
  disp=c_1-c_2;
  mean_dist=CalcMHWScore(disparity_array);
  printf("Mean_dist: %f \n",mean_dist);
  printf("Number of descriptors: %d %d %lu\n",descriptors_1.rows,descriptors_2.rows,matches.size());
  // //-- Draw only "good" matches
  if(descriptors_1.rows*descriptors_2.rows*keypoints_1.size()*keypoints_2.size()>0){
  drawMatches( roi1, keypoints_1, roi2, keypoints_2,
               good_matches, img_matches, Scalar::all(-1), Scalar::all(-1),
               vector<char>(), DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS );
  // //-- Show detected matches
    imshow( "Good Matches", img_matches );
   }
  // for( int i = 0; i < (int)good_matches.size(); i++ )
  // { printf( "-- Good Match [%d] Keypoint 1: %d  -- Keypoint 2: %d  \n", i, good_matches[i].queryIdx, good_matches[i].trainIdx ); }
  waitKey(1);
}


void distance(){

		std::ostringstream strs1,strs2,strs3,strs4;
		strs1 << abs(disp);
		std::string str1 = strs1.str();

		strs2 << abs(mean_dist);
		std::string str2 = strs2.str();

		disp+=mean_dist;
		strs3 << abs(disp);
		std::string str3 = strs3.str();

		cv::Mat pic = cv::Mat::zeros(250,250,CV_8UC3);

		cv::putText(pic, "Disp:"+str1,cv::Point(50,50), CV_FONT_HERSHEY_SIMPLEX, 0.5,cv::Scalar(255),1,8,false);
		cv::putText(pic, "Mean_dist:"+str2,cv::Point(50,100), CV_FONT_HERSHEY_SIMPLEX, 0.5,cv::Scalar(255),1,8,false);
		cv::putText(pic, "Correct:"+str3,cv::Point(50,150), CV_FONT_HERSHEY_SIMPLEX, 0.5,cv::Scalar(255),1,8,false);

		imshow("Distance",pic);
		// gray_diff();
	}
//  return abs(b*f/((x1-x2)));


Mat removeblue(Mat bluebarrel,string cam)
{	
	Mat bw,initial,cropped=Mat::zeros(cvSize(100, 100), CV_8UC3);
	
	namedWindow("test_left"+cam,CV_WINDOW_AUTOSIZE);
	createTrackbar("hue_low","test_left"+cam, &hue_low, 255);
	createTrackbar("hue_high","test_left"+cam, &hue_high, 255);
	createTrackbar("sat_low","test_left"+cam, &sat_low, 255);
	createTrackbar("sat_high","test_left"+cam, &sat_high, 255);
	createTrackbar("val_low","test_left"+cam, &val_low, 255);
	createTrackbar("val_high","test_left"+cam, &val_high, 255);
	createTrackbar("circle_sensitivity","test_left"+cam, &circle_sensitivity, 100);
	hue_low = getTrackbarPos("hue_low","test_left"+cam);
	hue_high = getTrackbarPos("hue_high","test_left"+cam);
	sat_low = getTrackbarPos("sat_low","test_left"+cam);
	sat_high = getTrackbarPos("sat_high","test_left"+cam);
	val_low = getTrackbarPos("val_low","test_left"+cam);
	val_high = getTrackbarPos("val_high","test_left"+cam);
	inRange(bluebarrel,Scalar(hue_low,sat_low,val_low),Scalar(hue_high,sat_high,val_high),bw);//detects red
	erode(bw, bw, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)) );

	GaussianBlur( bw, bw, Size(9, 9), 0,0);
	imshow("test_left"+cam,bw);
  	vector<Vec3f> circles;
  	HoughCircles( bw, circles, CV_HOUGH_GRADIENT, 1, bw.rows/8, 100,getTrackbarPos("circle_sensitivity","test_left"+cam), 5, 0 );
  	//cout<<circles.size();
  	  waitKey(1);
  	for( int i = 0; i < circles.size(); i++ )
  	{
      Point center(cvRound(circles[i][0]), cvRound(circles[i][1]));
      double radius = cvRound(circles[i][2]);
          //	 Mat cropped(bluebarrel,Rect(max(circles[i][0]-2*radius,0),max(circles[i][1]-2*radius,0),min(4*radius,640-(circles[i][0]+2*radius)),min(4*radius,640-(circles[i][0]+2*radius))));
      double x1=circles[i][0],y1=circles[i][1];
      double xc=max(x1-2*radius,0.0);
      double yc=max(y1-2*radius,0.0);
      double w=min(4*radius,1280.0-xc);
      double h=min(4*radius,720.0-yc);
      if(cam=="R")
      c_1=x1+0.5*w;
  	else
  		c_2=x1+0.5*w;
      Mat cropped(bluebarrel,Rect(xc,yc,w,h));
      	found++;
   	// cvtColor(cropped,cropped, cv::COLOR_BGR2GRAY);
      return cropped;
   }
   return bw;
}

void rightimage(const sensor_msgs::ImageConstPtr& original_image)
{
cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(original_image, enc::BGR8);
	}
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("videofeed::igvc_IPM.cpp::cv_bridge exception: %s", e.what());
        return;
    }
    src_right = cv_ptr->image;
     temp1=src_right.clone();
     found=0;
     cropped1=removeblue(temp1,"R");
     cropped1.copyTo(roi1);
     // imshow("ROI_R",roi1);
    detector->detectAndCompute( roi1, Mat(), keypoints_1, descriptors_1 );
     imshow("sampleR",temp1);
 //    cv_ptr->image = temp1;
    pub_right.publish(cv_ptr->toImageMsg());
    waitKey(1);
}

void leftimage(const sensor_msgs::ImageConstPtr& original_image)
{
	cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(original_image, enc::BGR8);
	}
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("videofeed::igvc_IPM.cpp::cv_bridge exception: %s", e.what());
        return;
    }

    src = cv_ptr->image;
     temp3=src.clone();
    cropped2=removeblue(temp3,"L");
      cropped2.copyTo(roi2);
     detector->detectAndCompute( roi2, Mat(), keypoints_2, descriptors_2 );
     imshow("sampleL",temp3);
     if(found==2){
		sift();
		distance();
	}

    printf("%d \n",found);
	cv_ptr->image = temp3;
    pub_left.publish(cv_ptr->toImageMsg());
    waitKey(1);
}


int main(int argc, char **argv)
{	
    ros::init(argc, argv, "Lane_D");
    ros::NodeHandle nh1;
    ros::NodeHandle nh2;

	image_transport::ImageTransport it1(nh1);
	image_transport::ImageTransport it2(nh2);
	image_transport::Subscriber sub_left = it1.subscribe("/camera1/image_raw", 1, rightimage);
	image_transport::Subscriber sub_right = it2.subscribe("/camera3/image_raw", 1, leftimage);


	ros::Rate loop_rate(2);
	while(ros::ok())
	{	
		ros::spinOnce();
		// distance();

		loop_rate.sleep();

		
	}

	ROS_INFO("videofeed::occupancygrid.cpp::No error.");

}