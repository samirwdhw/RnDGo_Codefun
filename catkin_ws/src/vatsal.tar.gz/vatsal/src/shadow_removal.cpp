#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2/imgproc/imgproc.hpp"
#include <opencv2/opencv.hpp>
//#include <opencv2/core/utility.hpp>
//#include "opencv2/imgcodecs.hpp"

// #include <opencv2/imgcodecs.hpp>
#include <stdio.h>
#include <string.h>
#include <iostream>
#include "stdlib.h"

using namespace cv;
using namespace std;

int threshval = 100;
Mat img;
static void on_trackbar(int, void*)
{
    Mat bw = threshval < 128 ? (img < threshval) : (img > threshval);
    Mat labelImage(img.size(), CV_32S);
    int nLabels = connectedComponents(bw, labelImage, 8);
    std::vector<Vec3b> colors(nLabels);
    colors[0] = Vec3b(0, 0, 0);//background
    for(int label = 1; label < nLabels; ++label){
        colors[label] = Vec3b( (rand()&255), (rand()&255), (rand()&255) );
    }
    Mat dst(img.size(), CV_8UC3);
    for(int r = 0; r < dst.rows; ++r){
        for(int c = 0; c < dst.cols; ++c){
            int label = labelImage.at<int>(r, c);
            Vec3b &pixel = dst.at<Vec3b>(r, c);
            pixel = colors[label];
         }
     }

    imshow( "Connected Components", dst );
}

int main()
{ 
	Mat src =imread("anish6.jpg");
	Mat img_hsv,otsu,ratio,median,erosion,dilation,buffer;
	cvtColor(src,img_hsv,CV_RGB2HSV);
	imshow("HSV",img_hsv);
	vector<Mat> channels;
	split(img_hsv, channels);
	imshow("H",channels[0]);
	imshow("S",channels[1]);
	imshow("V",channels[2]);
	ratio=120*(channels[0]/255+1)/(channels[2]/255+1);
	imshow("ratio_image",ratio);
	cv::threshold(ratio,otsu, 0, 255, CV_THRESH_BINARY | CV_THRESH_OTSU);
	imshow("Otsu",otsu);
	medianBlur(otsu, median, 5);
	imshow("Median",median);
	int erosion_size=3;
  	Mat element = getStructuringElement( cv::MORPH_RECT,
                                       Size( 2*erosion_size + 1, 2*erosion_size+1 ),
                                       Point( erosion_size, erosion_size ) );
  	erode( median, erosion, element );
  	imshow("Erosion",erosion);
  	dilate( erosion, dilation, element );
  	imshow("Dilation",dilation);
   namedWindow( "Image", 1 );
    imshow( "Image", dilation );
    img=dilation;
    namedWindow( "Connected Components", 1 );
    createTrackbar( "Threshold", "Connected Components", &threshval, 255, on_trackbar );
	on_trackbar(threshval, 0);
	waitKey(0);
	return 0;
}