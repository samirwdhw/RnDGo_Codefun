#include "image_properties.h"
//ros libraries
#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "nav_msgs/OccupancyGrid.h"
//c++ libraries
#include <iostream>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <string>
#include <fstream>

using namespace cv;
using namespace std;

namespace enc = sensor_msgs::image_encodings;

ros::Subscriber sub_Lanedata_left;
ros::Subscriber sub_Lanedata_right;
//Use method of ImageTransport to create image publisher
image_transport::Publisher pub_left;
image_transport::Publisher pub_right;




Rect* RightROI;
Rect* LeftROI;
Point p_left,p_right;


Mat src,temp1,temp2,temp3,temp4,blank,dst,blue,map1_left,map2_left,map1_right,map2_right,src_right,gray1,gray2,diff;
vector<Mat> BGR;
Mat kernel_dilate;

void rightimage(const sensor_msgs::ImageConstPtr& original_image)
{
cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(original_image, enc::BGR8);
	}
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("videofeed::igvc_IPM.cpp::cv_bridge exception: %s", e.what());
        return;
    }
    src_right = cv_ptr->image;
    temp1=src_right;
	

    remap(src_right, temp1, map1_right, map2_right, CV_INTER_LINEAR);
	resize(temp1, temp1, Size (640,480));
	temp1 = temp1(Rect(0,40,640,440));
    cv_ptr->image = temp1;
    pub_right.publish(cv_ptr->toImageMsg());
    waitKey(1);
}

void leftimage(const sensor_msgs::ImageConstPtr& original_image)
{
	cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(original_image, enc::BGR8);
	}
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("videofeed::igvc_IPM.cpp::cv_bridge exception: %s", e.what());
        return;
    }

    src = cv_ptr->image;
    temp3=src;
    remap(src, temp3, map1_left, map2_left, CV_INTER_LINEAR);
	resize(temp3, temp3, Size (640,480));
	temp3 = temp3(Rect(0,40,640,440));
	cv_ptr->image = temp3;
    pub_left.publish(cv_ptr->toImageMsg());
    waitKey(1);
}


int main(int argc, char **argv)
{	
    ros::init(argc, argv, "Lane_D");
    ros::NodeHandle nh1;
    ros::NodeHandle nh2;

	image_transport::ImageTransport it1(nh1);
	image_transport::ImageTransport it2(nh2);
	image_transport::Subscriber sub_right = it2.subscribe("/camera3/image_raw", 1, rightimage);
	image_transport::Subscriber sub_left = it1.subscribe("/camera1/image_raw", 1, leftimage);

	pub_right = it2.advertise("/camera/image_raw3", 1);
	pub_left = it1.advertise("/camera/image_raw1", 1);

	ros::Rate loop_rate(20);

	// std::ifstream matleft("/home/anish/catkin_ws/src/vatsal/src/NL_intrinsic_matrix_left.txt",std::ios::in);
	// std::ifstream distleft("/home/anish/catkin_ws/src/vatsal/src/distCoeff_left.txt",std::ios::in);
	// std::ifstream matright("/home/anish/catkin_ws/src/vatsal/src/intrinsic_matrix_right.txt",std::ios::in);
	// std::ifstream distright("/home/anish/catkin_ws/src/vatsal/src/distCoeff_right.txt",std::ios::in);

	  std::ifstream matleft("/home/anish/catkin_ws/src/vatsal/src/intrinsic_matrix_left (copy).txt",std::ios::in);
	  std::ifstream distleft("/home/anish/catkin_ws/src/vatsal/src/distCoeff_left (copy).txt",std::ios::in);
	  std::ifstream matright("/home/anish/catkin_ws/src/vatsal/src/intrinsic_matrix_right (copy).txt",std::ios::in);
	  std::ifstream distright("/home/anish/catkin_ws/src/vatsal/src/distCoeff_right (copy).txt",std::ios::in);


	std::vector<double> a,b;
	std::vector<double> distCoeff_left;
	 double num1 = 0.0;
	while (matleft >> num1) {
        a.push_back(num1);
    }
    double num2 = 0.0;
    while (distleft >> num2) {
        distCoeff_left.push_back(num2);
    }
    matleft.close();
    distleft.close();
    Mat intrinsic_matrix_left = (Mat_<double>(3,3) << a[0], a[1], a[2], a[3],a[4], a[5], a[6], a[7], a[8]);
    //Mat newmat_left = getOptimalNewCameraMatrix(intrinsic_matrix_left, distCoeff_left,Size (1280,720), 5.5,Size (1280,720), LeftROI, true);
    initUndistortRectifyMap(intrinsic_matrix_left, distCoeff_left, Mat::eye(3, 3, CV_16S), intrinsic_matrix_left, Size (1280,720), CV_32FC1, map1_left, map2_left);
    a.clear();
    distCoeff_left.clear();
    //newmat_left.release();
    intrinsic_matrix_left.release();

	std::vector<double> distCoeff_right;
	num1 = 0.0;
	while (matright >> num1) {
         b.push_back(num1);
     }
     num2 = 0.0;
     while (distright >> num2) {
         distCoeff_right.push_back(num2);
     }
     matright.close();
     distright.close();

     Mat intrinsic_matrix_right = (Mat_<double>(3,3) << b[0], b[1], b[2], b[3],b[4], b[5], b[6], b[7], b[8]);
     //Mat newmat_right = getOptimalNewCameraMatrix(intrinsic_matrix_right, distCoeff_right,Size (1280,720), 5.8,Size (1280,720), RightROI, true);
     initUndistortRectifyMap(intrinsic_matrix_right, distCoeff_right, Mat::eye(3, 3, CV_16S), intrinsic_matrix_right, Size (1280,720), CV_32FC1, map1_right, map2_right);
     b.clear();
     distCoeff_right.clear();
     //newmat_right.release();
     intrinsic_matrix_right.release();

	while(ros::ok())
	{	
		ros::spinOnce();
		loop_rate.sleep();
		
	}

	ROS_INFO("videofeed::occupancygrid.cpp::No error.");

}