#include "opencv2/core/core.hpp"
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
//ros libraries
#include "image_properties.h"
#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "nav_msgs/OccupancyGrid.h"
//c++ libraries
#include <iostream>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <string>
#include <fstream>
//#include <random>
//#include "opencv2/ml/ml.hpp"
#include <opencv2/opencv.hpp>
#include <math.h> 
#include <ctime>

using namespace cv;
using namespace std;

namespace enc = sensor_msgs::image_encodings;
ros::Subscriber sub;
image_transport::Publisher pub;

//P,L,O,U
Mat lane_masked, shadow_masked, road_masked, not_road_masked, variance_masked, temp3, src, avg_road, stddev_road, avg_lane, stddev_lane, median_sigma, frame;
Mat saturation;
vector<float> mean_I(4), sigma_I(4),mean_L(2),sigma_L(2),mean_V(2), sigma_V(2),mean_S(2), sigma_S(2), weights_I, weights_L, weights_V, weights_S;
float mean_src, stddev_src, prior_mean, prior_stddev;
Scalar avg, stddev;
Mat labels;

int aux=0, tau=8;

// void ExpMax(Mat image, Mat lane_filtered){
//     const int N = 4;

//     int i, j;
//     cout<<image.rows<<endl;
//     int nsamples = image.rows * image.cols;
//     Mat samples=image;
//     Mat labels;
//     Mat img = Mat::zeros( image.rows, image.cols, CV_8UC1 );
//     samples = samples.reshape(0, nsamples);
//     Mat lane_samples = lane_filtered.reshape(0, nsamples);
//     hconcat(samples, lane_samples,samples);
//     // cluster the data
//     Ptr<EM> em_model = EM::create();
//     em_model->setClustersNumber(N);
//     em_model->setCovarianceMatrixType(EM::COV_MAT_DIAGONAL);
//     em_model->setTermCriteria(TermCriteria(TermCriteria::COUNT+TermCriteria::EPS, 100, 0.1));
//     em_model->trainEM(samples, noArray(), labels, noArray() );

//     labels=120*labels.reshape(0, image.rows);
//     imshow("labels",120*labels);

//     for(int i=0;i<nsamples;i++){
//         cout<<labels.at<int>(i)<<" "<<i<<" ";
//     }
// }


void show_histogram(Mat gray, String histname){
      int histSize = 256;

  /// Set the ranges ( for B,G,R) )
  float range[] = { 1, 256 } ;
  const float* histRange = { range };

  bool uniform = true; bool accumulate = false;

  Mat b_hist, g_hist, r_hist;

  /// Compute the histograms:
  calcHist( &gray, 1, 0, Mat(), b_hist, 1, &histSize, &histRange, uniform, accumulate );

  // Draw the histograms for B, G and R
  int hist_w = 512; int hist_h = 400;
  int bin_w = cvRound( (double) hist_w/histSize );

  Mat histImage( hist_h, hist_w, CV_8UC3, Scalar( 0,0,0) );

  /// Normalize the result to [ 0, histImage.rows ]
  normalize(b_hist, b_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat() );

  /// Draw for each channel
  for( int i = 1; i < histSize; i++ )
  {
      line( histImage, Point( bin_w*(i-1), hist_h - cvRound(b_hist.at<float>(i-1)) ) ,
                       Point( bin_w*(i), hist_h - cvRound(b_hist.at<float>(i)) ),
                       Scalar( 255, 0, 0), 2, 8, 0  );
  }

  /// Display
  namedWindow(histname, CV_WINDOW_AUTOSIZE );
  imshow(histname, histImage );
}

Mat lane_filter_image(Mat src){
      //cvtColor(temp3,temp3,CV_RGB2GRAY);
    Mat dst=Mat::zeros(src.rows, src.cols, CV_8U);
    // dst= Mat.zeros(temp3.rows(), temp3.cols(), CV_8U);

    createTrackbar("tau","controls", &tau, 100);
    tau = getTrackbarPos("tau","controls");
    // thresh = getTrackbarPos("thresh","lane");
    //while(1){
    for(int j=0; j<src.rows; j++){

        unsigned char* ptRowSrc = src.ptr<uchar>(j);
        unsigned char* ptRowDst = dst.ptr<uchar>(j);

        for(int i = tau; i< src.cols-tau; i++){
            if(ptRowSrc[i]!=0){
                aux = 2*ptRowSrc[i];
                aux += -ptRowSrc[i-tau];
                aux += -ptRowSrc[i+tau];
                aux += -abs((int)(ptRowSrc[i-tau]-ptRowSrc[i+tau]));

                aux = (aux<0)?(0):(aux);
                aux = (aux>255)?(255):(aux);

                ptRowDst[i] = (unsigned char)aux;
            }
        }

    }
    //medianBlur(dst, dst, 5);
    return dst;
}

void lane_filter(Mat src){

    Mat dst=lane_filter_image(src);

    meanStdDev(dst, avg, stddev);
    float cutoff=avg[0];
    Mat lane2=dst<cutoff;
    meanStdDev(dst, avg, stddev, lane2);
    mean_L[0]=avg[0];
    sigma_L[0]=stddev[0];

    lane2=dst>cutoff;
    imshow("lane1",dst);
    show_histogram(dst, "lanehist");
    meanStdDev(dst, avg, stddev, lane2);
    mean_L[1]=avg[0];
    sigma_L[1]=stddev[0];

    // meanStdDev(src, avg, stddev, lane2);
    // mean_I[1]=avg[0];
    // sigma_I[1]=stddev[0];
    
    dst.copyTo(lane2, lane2);
    imshow("lane2",lane2);
    show_histogram(lane2, "Lane filter");

}

void intensity_filter(Mat image){

  lane_masked = image > mean_I[0]+3*sigma_I[0];

  //lane_masked = image > min(mean_I[0]+3*sigma_I[0], mean_src+3*stddev_src);
  //lane_masked = image > 0.5*(mean_I[0]+mean_I[1]);
  meanStdDev(image, avg, stddev, lane_masked);
  //threshold(img,lane_masked, mean_I[0]+3*sigma_I[0], 255, THRESH_BINARY);
  image.copyTo(lane_masked,lane_masked);
  imshow("Lane_masked",lane_masked);
  show_histogram(lane_masked, "Intensity lane");
    
    mean_I[1]=avg[0];
    sigma_I[1]=stddev[0];

  
  shadow_masked = image < mean_I[0]-3*sigma_I[0];
  //shadow_masked = image < max(mean_I[0]-3*sigma_I[0], mean_src-3*stddev_src);
  //shadow_masked = image < 0.5*(mean_I[0]+mean_I[2]);
  meanStdDev(image, avg, stddev, shadow_masked);
  //threshold(img,lane_masked, mean_I[0]+3*sigma_I[0], 255, THRESH_BINARY);
  image.copyTo(shadow_masked,shadow_masked);
  imshow("Shadow_masked",shadow_masked);
  show_histogram(shadow_masked, "Intensity shadow");
    
    mean_I[2]=avg[0];
    sigma_I[2]=stddev[0];
}

Mat mat2gray(const Mat& src)
{
    Mat dst;
    normalize(src, dst, 0.0, 1.0, NORM_MINMAX);
    return dst;
}

void variance_filter(Mat image){

    Mat image32f;
    image.convertTo(image32f, CV_32F);

    Mat mu;
    blur(image32f, mu, Size(3, 3));

    Mat mu2;
    blur(image32f.mul(image32f), mu2, Size(3, 3));

    Mat sigma;
    cv::sqrt(mu2 - mu.mul(mu), sigma);
    imshow("sigma",mat2gray(sigma));
    medianBlur(sigma, median_sigma, 5);
    imshow("median_sigma",mat2gray(median_sigma));
    show_histogram(sigma, "sigma_hist");
    show_histogram(median_sigma, "median_sigma_hist");



    meanStdDev(sigma, avg, stddev);
    Mat variance( Size(image.rows, image.cols), CV_8U, Scalar(0));
    variance = sigma < avg[0]-0*stddev[0];

    meanStdDev(sigma, avg, stddev, variance);
    mean_V[0]=avg[0];
    sigma_V[0]=stddev[0];

    Mat not_variance=255-variance;
    meanStdDev(sigma, avg, stddev, not_variance);
    mean_V[1]=avg[0];
    sigma_V[1]=stddev[0];

  int dilation_size=10;
  Mat element = getStructuringElement( MORPH_RECT,
                                       Size( 2*dilation_size + 1, 2*dilation_size+1 ),
                                       Point( dilation_size, dilation_size ) );
    

  /// Apply the dilation operation
    road_masked=Mat::zeros( image.rows, image.cols, CV_8UC1 );
    erode( variance,variance, element );
    imshow("variance",variance);
    image.copyTo(road_masked, variance);
    // not_road_masked = image-road_masked;
    // imshow("not_road",not_road_masked);
    imshow("road_masked",road_masked);
    meanStdDev(image, avg, stddev, variance);
    mean_I[0]=avg[0];
    sigma_I[0]=stddev[0];
    show_histogram(road_masked, "road_hist");
}

Mat saturation_filter_image(Mat img){
    vector<Mat> channels;
    cvtColor(img, img, CV_BGR2HSV);
    split(img, channels);
    Mat saturation=channels[1];
    return saturation;
}


Mat bayesian(Mat img, Mat lf, Mat sf){
    // int w;
    // createTrackbar("weights_I[0]","controls", &weights_I, 100);
    // weights_I[0] = getTrackbarPos("weights_I[0]","controls")/100;

  Mat intensity_filter, lane_filter, variance_filter, saturation_filter;

  img.convertTo(intensity_filter, CV_32FC1);
  lf.convertTo(lane_filter, CV_32FC1);
  sf.convertTo(saturation_filter, CV_32FC1); 
  median_sigma.convertTo(variance_filter, CV_32FC1); 
  Mat labels[4] = Mat::zeros( intensity_filter.rows, intensity_filter.cols, CV_32FC1 );

  for(int i=0;i<1;i++){
  // labels[4] = Mat::zeros( intensity_filter.rows, intensity_filter.cols, CV_32FC1 );
  Mat intensity[4] = Mat::zeros( intensity_filter.rows, intensity_filter.cols, CV_32FC1 );
  Mat variance[2] = Mat::zeros( intensity_filter.rows, intensity_filter.cols, CV_32FC1 );
  Mat lane[2] = Mat::zeros( intensity_filter.rows, intensity_filter.cols, CV_32FC1 ); 
  Mat saturation[2] = Mat::zeros( intensity_filter.rows, intensity_filter.cols, CV_32FC1 ); 
  Mat prob[4] = Mat::zeros( intensity_filter.rows, intensity_filter.cols, CV_32FC1 );
  Mat sum_I=Mat::zeros( intensity_filter.rows, intensity_filter.cols, CV_32FC1 );
  Mat sum_L=Mat::zeros( intensity_filter.rows, intensity_filter.cols, CV_32FC1 );
  Mat sum_V=Mat::zeros( intensity_filter.rows, intensity_filter.cols, CV_32FC1 );
  Mat sum_S=Mat::zeros( intensity_filter.rows, intensity_filter.cols, CV_32FC1 );
  Mat maxm=Mat::zeros( intensity_filter.rows, intensity_filter.cols, CV_32FC1 );

  //vector<float> prob(4), intensity(4), lane(4);
  for(int k=0;k<4;k++){

    if(mean_I[k]>0){
    intensity[k]=intensity_filter-mean_I[k];
    pow(intensity[k],2,intensity[k]);
    intensity[k]/= -2*pow(sigma_I[k],2);
    exp(intensity[k],intensity[k]);
    intensity[k]=weights_I[k]*intensity[k]/sigma_I[k];
  }
    int l=k==1, v=k==3, s=v;
    // lane[l]=lane_filter-mean_L[l];
    // pow(lane[l],2,lane[l]);
    // lane[l]/= -2*pow(sigma_L[l],2);
    // exp(lane[l],lane[l]);
    // lane[l]=weights_L[l]*lane[l]/sigma_L[l];

    variance[v]=variance_filter-mean_V[v];
    pow(variance[v],2,variance[v]);
    variance[v]/= -2*pow(sigma_V[v],2);
    exp(variance[v],variance[v]);
    variance[v]=weights_V[v]*variance[v]/sigma_V[v];

    saturation[s]=saturation_filter-mean_S[s];
    pow(saturation[s],2,saturation[s]);
    saturation[s]/= -2*pow(sigma_S[s],2);
    exp(saturation[s],saturation[s]);
    saturation[s]=weights_S[s]*saturation[s]/sigma_S[s];

    //labels[k]=intensity[k].mul(lane[l]);
    labels[k]=intensity[k].mul(variance[v]);
    //labels[k]=labels[k].mul(variance[v]);
    labels[k]=labels[k].mul(saturation[s]);
    // labels[k]=intensity[k];
    //labels[k]=lane[l];
    sum_I+=intensity[k];
    //sum_L+=lane[l];
    sum_V+=variance[v];
    sum_S+=saturation[s];
    }
    for(int k=0;k<4;k++){
      labels[k]=labels[k].mul(1/sum_I);
      //labels[k]=labels[k].mul(1/sum_L);
      labels[k]=labels[k].mul(1/sum_V);
      labels[k]=labels[k].mul(1/sum_S);
      medianBlur(labels[k], labels[k], 5);
      //labels[k].convertTo(labels[k], CV_8UC1);
      //labels[k]=labels[k]>0.4;
      max(maxm, labels[k], maxm);
    }
    for(int k=0;k<3;k++){
      labels[k]=labels[k]==maxm;
      meanStdDev(intensity_filter, avg, stddev, labels[k]);
      if(avg[0]>0){
      prior_mean=mean_I[k];
      prior_stddev=sigma_I[k];
      // mean_I[k]=(pow(stddev[0],2)*prior_mean+ avg[0]*pow(sigma_I[k],2))/(pow(stddev[0],2) + pow(sigma_I[k],2));
      // sigma_I[k]=pow(stddev[0]*sigma_I[k],2)/(pow(stddev[0],2) + pow(sigma_I[k],2));
      mean_I[k]=avg[0];
      sigma_I[k]=stddev[0];
      weights_I[k]=(float)countNonZero(labels[k])/(float)labels[k].total();
    }
    }

    imshow("maxm",maxm);
    labels[3]=labels[3]==maxm;
    weights_I[3]=(float)countNonZero(labels[3])/(float)labels[3].total();
    // Mat not_lane_mask=255-labels[1];
    // meanStdDev(lane_filter,avg, stddev, labels[1]);
    // mean_L[1]=avg[0];
    // sigma_L[1]=stddev[0];
    // weights_L[1]=(float)countNonZero(labels[1])/(float)labels[1].total();

    // meanStdDev(lane_filter, avg, stddev, not_lane_mask);
    // mean_L[0]=avg[0];
    // sigma_L[0]=stddev[0];
    // weights_L[0]=1-weights_L[1];

    Mat not_variance_mask=255-labels[3];
    meanStdDev(variance_filter,avg, stddev, labels[3]);
    mean_V[1]=avg[0];
    sigma_V[1]=stddev[0];
    weights_V[1]=(float)countNonZero(labels[3])/(float)labels[3].total();

    meanStdDev(variance_filter, avg, stddev, not_variance_mask);
    mean_V[0]=avg[0];
    sigma_V[0]=stddev[0];
    weights_V[0]=1-weights_V[1];

    meanStdDev(saturation_filter,avg, stddev, labels[3]);
    mean_S[1]=avg[0];
    sigma_S[1]=stddev[0];
    weights_S[1]=(float)countNonZero(labels[3])/(float)labels[3].total();

    meanStdDev(saturation_filter, avg, stddev, not_variance_mask);
    mean_S[0]=avg[0];
    sigma_S[0]=stddev[0];
    weights_S[0]=1-weights_S[1];
    cout<<"POSTERIOR"<<endl;
    // for(int i=0;i<4;i++){
    //   cout<<mean_I[i]<<" "<<sigma_I[i]<<endl;
    // }
    for(int i=0;i<4;i++){
      cout<<weights_I[i]<<" ";
    }
    cout<<weights_L[0]<<" "<<weights_L[1]<<endl;

imshow("ROAD",labels[0]);
imshow("LANE",labels[1]);
imshow("SHADOW",labels[2]);
Mat road=255-labels[3];
//imshow("SUM",road);
imshow("UNKNOWN",labels[3]);
cout<<endl;
}
Mat dst;
labels[0].convertTo(dst, CV_8UC1);
return dst;
}

void road_detect(const sensor_msgs::ImageConstPtr& original_image)
{	

  cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(original_image, enc::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("videofeed::igvc_IPM.cpp::cv_bridge exception: %s", e.what());
        return;
    }

    frame = cv_ptr->image;

    cvtColor(frame, frame, CV_BGR2GRAY);
    //src = frame(Rect(0, 0.2*frame.rows, frame.cols, 0.5*frame.rows));
    
    //normalize(src,src, 255, 0);
    src=frame;
    vector<Mat> channels;
    resize(src, src, Size (640,480));
    namedWindow("controls",CV_WINDOW_AUTOSIZE);
    cvtColor(src, frame, CV_BGR2HSV);
    split(frame, channels);
    
    saturation=saturation_filter_image(src);
    src = channels[2];
    imshow("saturation",saturation);
    show_histogram(saturation,"saturation_hist");
    //medianBlur(src, src, 3);
    imshow("lane",src);
    meanStdDev(src, avg, stddev);
    mean_src=avg[0];
    stddev_src=stddev[0];
    variance_filter(src);
    show_histogram(src, "src_hist");
    intensity_filter(src);
    lane_filter(src);
    //cout<<2;
    Mat vk=lane_filter_image(src);
    Mat road = bayesian(src,vk, saturation);
    //cout<<3;
    cv_ptr->image = road;
    pub.publish(cv_ptr->toImageMsg());
    //cout<<4;
    waitKey(1);
}

int main(int argc, char **argv)
{ 
  ros::init(argc, argv, "Road");
  ros::NodeHandle nh;

  image_transport::ImageTransport it(nh);
  image_transport::Subscriber sub = it.subscribe("/camera/image_raw", 1, road_detect);
  pub = it.advertise("/camera/bayesian", 1);
  ros::Rate loop_rate(10);
  mean_I[3]=127;
  sigma_I[3]=25500;

  weights_I.clear();
  weights_L.clear();
  weights_V.clear();
  weights_I.push_back(10);
  weights_I.push_back(1);
  weights_I.push_back(1);
  weights_I.push_back(1);
  weights_L.push_back(10);
  weights_L.push_back(1);
  weights_V.push_back(10);
  weights_V.push_back(1);
  weights_S.push_back(10);
  weights_S.push_back(1);

  while(ros::ok())
  { 
    ros::spinOnce();
    loop_rate.sleep();  
  }
  ROS_INFO("videofeed::occupancygrid.cpp::No error.");
}